var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir4, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env3) {
    return 1;
  }
  hasColors(count4, env3) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process2 extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process2.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd3) {
    this.#cwd = cwd3;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var isWorkerdProcessV2 = globalThis.Cloudflare.compatibilityFlags.enable_nodejs_process_v2;
var unenvProcess = new Process({
  env: globalProcess.env,
  // `hrtime` is only available from workerd process v2
  hrtime: isWorkerdProcessV2 ? workerdProcess.hrtime : hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  // Always implemented by workerd
  env,
  // Only implemented in workerd v2
  hrtime: hrtime3,
  // Always implemented by workerd
  nextTick
} = unenvProcess;
var {
  _channel,
  _disconnect,
  _events,
  _eventsCount,
  _handleQueue,
  _maxListeners,
  _pendingMessage,
  _send,
  assert: assert2,
  disconnect,
  mainModule
} = unenvProcess;
var {
  // @ts-expect-error `_debugEnd` is missing typings
  _debugEnd,
  // @ts-expect-error `_debugProcess` is missing typings
  _debugProcess,
  // @ts-expect-error `_exiting` is missing typings
  _exiting,
  // @ts-expect-error `_fatalException` is missing typings
  _fatalException,
  // @ts-expect-error `_getActiveHandles` is missing typings
  _getActiveHandles,
  // @ts-expect-error `_getActiveRequests` is missing typings
  _getActiveRequests,
  // @ts-expect-error `_kill` is missing typings
  _kill,
  // @ts-expect-error `_linkedBinding` is missing typings
  _linkedBinding,
  // @ts-expect-error `_preload_modules` is missing typings
  _preload_modules,
  // @ts-expect-error `_rawDebug` is missing typings
  _rawDebug,
  // @ts-expect-error `_startProfilerIdleNotifier` is missing typings
  _startProfilerIdleNotifier,
  // @ts-expect-error `_stopProfilerIdleNotifier` is missing typings
  _stopProfilerIdleNotifier,
  // @ts-expect-error `_tickCallback` is missing typings
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  availableMemory,
  // @ts-expect-error `binding` is missing typings
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  // @ts-expect-error `domain` is missing typings
  domain,
  emit,
  emitWarning,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  // @ts-expect-error `initgroups` is missing typings
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  memoryUsage,
  // @ts-expect-error `moduleLoadList` is missing typings
  moduleLoadList,
  off,
  on,
  once,
  // @ts-expect-error `openStdin` is missing typings
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  // @ts-expect-error `reallyExit` is missing typings
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = isWorkerdProcessV2 ? workerdProcess : unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// .wrangler/tmp/pages-G43smt/bundledWorker-0.5194411378681534.mjs
import { Writable as Writable2 } from "node:stream";
import { EventEmitter as EventEmitter2 } from "node:events";
var __defProp2 = Object.defineProperty;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
// @__NO_SIDE_EFFECTS__
function createNotImplementedError2(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError2, "createNotImplementedError");
__name2(createNotImplementedError2, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented2(name) {
  const fn = /* @__PURE__ */ __name2(() => {
    throw /* @__PURE__ */ createNotImplementedError2(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented2, "notImplemented");
__name2(notImplemented2, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass2(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass2, "notImplementedClass");
__name2(notImplementedClass2, "notImplementedClass");
var _timeOrigin2 = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow2 = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin2;
var nodeTiming2 = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry2 = class {
  static {
    __name(this, "PerformanceEntry");
  }
  static {
    __name2(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow2();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow2() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark3 = class PerformanceMark22 extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMark2");
  }
  static {
    __name2(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMeasure");
  }
  static {
    __name2(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  static {
    __name2(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList2 = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  static {
    __name2(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance2 = class {
  static {
    __name(this, "Performance");
  }
  static {
    __name2(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin2;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming2;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming2("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin2) {
      return _performanceNow2();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark3(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure2(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver2 = class {
  static {
    __name(this, "PerformanceObserver");
  }
  static {
    __name2(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance2 = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance2();
globalThis.performance = performance2;
globalThis.Performance = Performance2;
globalThis.PerformanceEntry = PerformanceEntry2;
globalThis.PerformanceMark = PerformanceMark3;
globalThis.PerformanceMeasure = PerformanceMeasure2;
globalThis.PerformanceObserver = PerformanceObserver2;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList2;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming2;
var noop_default2 = Object.assign(() => {
}, { __unenv__: true });
var _console2 = globalThis.console;
var _ignoreErrors2 = true;
var _stderr2 = new Writable2();
var _stdout2 = new Writable2();
var log3 = _console2?.log ?? noop_default2;
var info3 = _console2?.info ?? log3;
var trace3 = _console2?.trace ?? info3;
var debug3 = _console2?.debug ?? log3;
var table3 = _console2?.table ?? log3;
var error3 = _console2?.error ?? log3;
var warn3 = _console2?.warn ?? error3;
var createTask3 = _console2?.createTask ?? /* @__PURE__ */ notImplemented2("console.createTask");
var clear3 = _console2?.clear ?? noop_default2;
var count3 = _console2?.count ?? noop_default2;
var countReset3 = _console2?.countReset ?? noop_default2;
var dir3 = _console2?.dir ?? noop_default2;
var dirxml3 = _console2?.dirxml ?? noop_default2;
var group3 = _console2?.group ?? noop_default2;
var groupEnd3 = _console2?.groupEnd ?? noop_default2;
var groupCollapsed3 = _console2?.groupCollapsed ?? noop_default2;
var profile3 = _console2?.profile ?? noop_default2;
var profileEnd3 = _console2?.profileEnd ?? noop_default2;
var time3 = _console2?.time ?? noop_default2;
var timeEnd3 = _console2?.timeEnd ?? noop_default2;
var timeLog3 = _console2?.timeLog ?? noop_default2;
var timeStamp3 = _console2?.timeStamp ?? noop_default2;
var Console2 = _console2?.Console ?? /* @__PURE__ */ notImplementedClass2("console.Console");
var _times2 = /* @__PURE__ */ new Map();
var _stdoutErrorHandler2 = noop_default2;
var _stderrErrorHandler2 = noop_default2;
var workerdConsole2 = globalThis["console"];
var {
  assert: assert3,
  clear: clear22,
  // @ts-expect-error undocumented public API
  context: context2,
  count: count22,
  countReset: countReset22,
  // @ts-expect-error undocumented public API
  createTask: createTask22,
  debug: debug22,
  dir: dir22,
  dirxml: dirxml22,
  error: error22,
  group: group22,
  groupCollapsed: groupCollapsed22,
  groupEnd: groupEnd22,
  info: info22,
  log: log22,
  profile: profile22,
  profileEnd: profileEnd22,
  table: table22,
  time: time22,
  timeEnd: timeEnd22,
  timeLog: timeLog22,
  timeStamp: timeStamp22,
  trace: trace22,
  warn: warn22
} = workerdConsole2;
Object.assign(workerdConsole2, {
  Console: Console2,
  _ignoreErrors: _ignoreErrors2,
  _stderr: _stderr2,
  _stderrErrorHandler: _stderrErrorHandler2,
  _stdout: _stdout2,
  _stdoutErrorHandler: _stdoutErrorHandler2,
  _times: _times2
});
var console_default2 = workerdConsole2;
globalThis.console = console_default2;
var hrtime4 = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name2(/* @__PURE__ */ __name(function hrtime22(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime2"), "hrtime"), { bigint: /* @__PURE__ */ __name2(/* @__PURE__ */ __name(function bigint2() {
  return BigInt(Date.now() * 1e6);
}, "bigint"), "bigint") });
var ReadStream2 = class {
  static {
    __name(this, "ReadStream");
  }
  static {
    __name2(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};
var WriteStream2 = class {
  static {
    __name(this, "WriteStream");
  }
  static {
    __name2(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir32, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env22) {
    return 1;
  }
  hasColors(count32, env22) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};
var NODE_VERSION2 = "22.14.0";
var Process2 = class _Process extends EventEmitter2 {
  static {
    __name(this, "_Process");
  }
  static {
    __name2(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter2.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream2(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream2(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream2(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd22) {
    this.#cwd = cwd22;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION2}`;
  }
  get versions() {
    return { node: NODE_VERSION2 };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw /* @__PURE__ */ createNotImplementedError2("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw /* @__PURE__ */ createNotImplementedError2("process.getActiveResourcesInfo");
  }
  exit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.exit");
  }
  reallyExit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.reallyExit");
  }
  kill() {
    throw /* @__PURE__ */ createNotImplementedError2("process.kill");
  }
  abort() {
    throw /* @__PURE__ */ createNotImplementedError2("process.abort");
  }
  dlopen() {
    throw /* @__PURE__ */ createNotImplementedError2("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw /* @__PURE__ */ createNotImplementedError2("process.loadEnvFile");
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("process.disconnect");
  }
  cpuUsage() {
    throw /* @__PURE__ */ createNotImplementedError2("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw /* @__PURE__ */ createNotImplementedError2("process.initgroups");
  }
  openStdin() {
    throw /* @__PURE__ */ createNotImplementedError2("process.openStdin");
  }
  assert() {
    throw /* @__PURE__ */ createNotImplementedError2("process.assert");
  }
  binding() {
    throw /* @__PURE__ */ createNotImplementedError2("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented2("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented2("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented2("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented2("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented2("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented2("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name2(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};
var globalProcess2 = globalThis["process"];
var getBuiltinModule2 = globalProcess2.getBuiltinModule;
var workerdProcess2 = getBuiltinModule2("node:process");
var isWorkerdProcessV22 = globalThis.Cloudflare.compatibilityFlags.enable_nodejs_process_v2;
var unenvProcess2 = new Process2({
  env: globalProcess2.env,
  // `hrtime` is only available from workerd process v2
  hrtime: isWorkerdProcessV22 ? workerdProcess2.hrtime : hrtime4,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess2.nextTick
});
var { exit: exit2, features: features2, platform: platform2 } = workerdProcess2;
var {
  // Always implemented by workerd
  env: env2,
  // Only implemented in workerd v2
  hrtime: hrtime32,
  // Always implemented by workerd
  nextTick: nextTick2
} = unenvProcess2;
var {
  _channel: _channel2,
  _disconnect: _disconnect2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _handleQueue: _handleQueue2,
  _maxListeners: _maxListeners2,
  _pendingMessage: _pendingMessage2,
  _send: _send2,
  assert: assert22,
  disconnect: disconnect2,
  mainModule: mainModule2
} = unenvProcess2;
var {
  // @ts-expect-error `_debugEnd` is missing typings
  _debugEnd: _debugEnd2,
  // @ts-expect-error `_debugProcess` is missing typings
  _debugProcess: _debugProcess2,
  // @ts-expect-error `_exiting` is missing typings
  _exiting: _exiting2,
  // @ts-expect-error `_fatalException` is missing typings
  _fatalException: _fatalException2,
  // @ts-expect-error `_getActiveHandles` is missing typings
  _getActiveHandles: _getActiveHandles2,
  // @ts-expect-error `_getActiveRequests` is missing typings
  _getActiveRequests: _getActiveRequests2,
  // @ts-expect-error `_kill` is missing typings
  _kill: _kill2,
  // @ts-expect-error `_linkedBinding` is missing typings
  _linkedBinding: _linkedBinding2,
  // @ts-expect-error `_preload_modules` is missing typings
  _preload_modules: _preload_modules2,
  // @ts-expect-error `_rawDebug` is missing typings
  _rawDebug: _rawDebug2,
  // @ts-expect-error `_startProfilerIdleNotifier` is missing typings
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  // @ts-expect-error `_stopProfilerIdleNotifier` is missing typings
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  // @ts-expect-error `_tickCallback` is missing typings
  _tickCallback: _tickCallback2,
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  availableMemory: availableMemory2,
  // @ts-expect-error `binding` is missing typings
  binding: binding2,
  channel: channel2,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  // @ts-expect-error `domain` is missing typings
  domain: domain2,
  emit: emit2,
  emitWarning: emitWarning2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  exitCode: exitCode2,
  finalization: finalization2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getMaxListeners: getMaxListeners2,
  getuid: getuid2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  // @ts-expect-error `initgroups` is missing typings
  initgroups: initgroups2,
  kill: kill2,
  listenerCount: listenerCount2,
  listeners: listeners2,
  loadEnvFile: loadEnvFile2,
  memoryUsage: memoryUsage2,
  // @ts-expect-error `moduleLoadList` is missing typings
  moduleLoadList: moduleLoadList2,
  off: off2,
  on: on2,
  once: once2,
  // @ts-expect-error `openStdin` is missing typings
  openStdin: openStdin2,
  permission: permission2,
  pid: pid2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  // @ts-expect-error `reallyExit` is missing typings
  reallyExit: reallyExit2,
  ref: ref2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  send: send2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  setuid: setuid2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  sourceMapsEnabled: sourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  throwDeprecation: throwDeprecation2,
  title: title2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  unref: unref2,
  uptime: uptime2,
  version: version2,
  versions: versions2
} = isWorkerdProcessV22 ? workerdProcess2 : unenvProcess2;
var _process2 = {
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  loadEnvFile: loadEnvFile2,
  sourceMapsEnabled: sourceMapsEnabled2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  availableMemory: availableMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  disconnect: disconnect2,
  emit: emit2,
  emitWarning: emitWarning2,
  env: env2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  exit: exit2,
  finalization: finalization2,
  features: features2,
  getBuiltinModule: getBuiltinModule2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getMaxListeners: getMaxListeners2,
  hrtime: hrtime32,
  kill: kill2,
  listeners: listeners2,
  listenerCount: listenerCount2,
  memoryUsage: memoryUsage2,
  nextTick: nextTick2,
  on: on2,
  off: off2,
  once: once2,
  pid: pid2,
  platform: platform2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  title: title2,
  throwDeprecation: throwDeprecation2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  uptime: uptime2,
  version: version2,
  versions: versions2,
  // @ts-expect-error old API
  domain: domain2,
  initgroups: initgroups2,
  moduleLoadList: moduleLoadList2,
  reallyExit: reallyExit2,
  openStdin: openStdin2,
  assert: assert22,
  binding: binding2,
  send: send2,
  exitCode: exitCode2,
  channel: channel2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getuid: getuid2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setuid: setuid2,
  permission: permission2,
  mainModule: mainModule2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _exiting: _exiting2,
  _maxListeners: _maxListeners2,
  _debugEnd: _debugEnd2,
  _debugProcess: _debugProcess2,
  _fatalException: _fatalException2,
  _getActiveHandles: _getActiveHandles2,
  _getActiveRequests: _getActiveRequests2,
  _kill: _kill2,
  _preload_modules: _preload_modules2,
  _rawDebug: _rawDebug2,
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  _tickCallback: _tickCallback2,
  _disconnect: _disconnect2,
  _handleQueue: _handleQueue2,
  _pendingMessage: _pendingMessage2,
  _channel: _channel2,
  _send: _send2,
  _linkedBinding: _linkedBinding2
};
var process_default2 = _process2;
globalThis.process = process_default2;
var Ur = Object.defineProperty;
var Tt = /* @__PURE__ */ __name2((e) => {
  throw TypeError(e);
}, "Tt");
var Br = /* @__PURE__ */ __name2((e, t, r) => t in e ? Ur(e, t, { enumerable: true, configurable: true, writable: true, value: r }) : e[t] = r, "Br");
var x = /* @__PURE__ */ __name2((e, t, r) => Br(e, typeof t != "symbol" ? t + "" : t, r), "x");
var it = /* @__PURE__ */ __name2((e, t, r) => t.has(e) || Tt("Cannot " + r), "it");
var h = /* @__PURE__ */ __name2((e, t, r) => (it(e, t, "read from private field"), r ? r.call(e) : t.get(e)), "h");
var E = /* @__PURE__ */ __name2((e, t, r) => t.has(e) ? Tt("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r), "E");
var b = /* @__PURE__ */ __name2((e, t, r, i) => (it(e, t, "write to private field"), i ? i.call(e, r) : t.set(e, r), r), "b");
var C = /* @__PURE__ */ __name2((e, t, r) => (it(e, t, "access private method"), r), "C");
var Rt = /* @__PURE__ */ __name2((e, t, r, i) => ({ set _(n) {
  b(e, t, n, r);
}, get _() {
  return h(e, t, i);
} }), "Rt");
var rr = { Stringify: 1 };
var $ = /* @__PURE__ */ __name2((e, t) => {
  const r = new String(e);
  return r.isEscaped = true, r.callbacks = t, r;
}, "$");
var Wr = /[&<>'"]/;
var sr = /* @__PURE__ */ __name2(async (e, t) => {
  let r = "";
  t || (t = []);
  const i = await Promise.all(e);
  for (let n = i.length - 1; r += i[n], n--, !(n < 0); n--) {
    let a = i[n];
    typeof a == "object" && t.push(...a.callbacks || []);
    const l = a.isEscaped;
    if (a = await (typeof a == "object" ? a.toString() : a), typeof a == "object" && t.push(...a.callbacks || []), a.isEscaped ?? l) r += a;
    else {
      const c = [r];
      re(a, c), r = c[0];
    }
  }
  return $(r, t);
}, "sr");
var re = /* @__PURE__ */ __name2((e, t) => {
  const r = e.search(Wr);
  if (r === -1) {
    t[0] += e;
    return;
  }
  let i, n, a = 0;
  for (n = r; n < e.length; n++) {
    switch (e.charCodeAt(n)) {
      case 34:
        i = "&quot;";
        break;
      case 39:
        i = "&#39;";
        break;
      case 38:
        i = "&amp;";
        break;
      case 60:
        i = "&lt;";
        break;
      case 62:
        i = "&gt;";
        break;
      default:
        continue;
    }
    t[0] += e.substring(a, n) + i, a = n + 1;
  }
  t[0] += e.substring(a, n);
}, "re");
var ir = /* @__PURE__ */ __name2((e) => {
  const t = e.callbacks;
  if (!(t != null && t.length)) return e;
  const r = [e], i = {};
  return t.forEach((n) => n({ phase: rr.Stringify, buffer: r, context: i })), r[0];
}, "ir");
var nr = /* @__PURE__ */ __name2(async (e, t, r, i, n) => {
  typeof e == "object" && !(e instanceof String) && (e instanceof Promise || (e = e.toString()), e instanceof Promise && (e = await e));
  const a = e.callbacks;
  return a != null && a.length ? (n ? n[0] += e : n = [e], Promise.all(a.map((c) => c({ phase: t, buffer: n, context: i }))).then((c) => Promise.all(c.filter(Boolean).map((o) => nr(o, t, false, i, n))).then(() => n[0]))) : Promise.resolve(e);
}, "nr");
var Jr = /* @__PURE__ */ __name2((e, ...t) => {
  const r = [""];
  for (let i = 0, n = e.length - 1; i < n; i++) {
    r[0] += e[i];
    const a = Array.isArray(t[i]) ? t[i].flat(1 / 0) : [t[i]];
    for (let l = 0, c = a.length; l < c; l++) {
      const o = a[l];
      if (typeof o == "string") re(o, r);
      else if (typeof o == "number") r[0] += o;
      else {
        if (typeof o == "boolean" || o === null || o === void 0) continue;
        if (typeof o == "object" && o.isEscaped) if (o.callbacks) r.unshift("", o);
        else {
          const d = o.toString();
          d instanceof Promise ? r.unshift("", d) : r[0] += d;
        }
        else o instanceof Promise ? r.unshift("", o) : re(o.toString(), r);
      }
    }
  }
  return r[0] += e.at(-1), r.length === 1 ? "callbacks" in r ? $(ir($(r[0], r.callbacks))) : $(r[0]) : sr(r, r.callbacks);
}, "Jr");
var bt = Symbol("RENDERER");
var mt = Symbol("ERROR_HANDLER");
var T = Symbol("STASH");
var ar = Symbol("INTERNAL");
var zr = Symbol("MEMO");
var Ze = Symbol("PERMALINK");
var Pt = /* @__PURE__ */ __name2((e) => (e[ar] = true, e), "Pt");
var lr = /* @__PURE__ */ __name2((e) => ({ value: t, children: r }) => {
  if (!r) return;
  const i = { children: [{ tag: Pt(() => {
    e.push(t);
  }), props: {} }] };
  Array.isArray(r) ? i.children.push(...r.flat()) : i.children.push(r), i.children.push({ tag: Pt(() => {
    e.pop();
  }), props: {} });
  const n = { tag: "", props: i, type: "" };
  return n[mt] = (a) => {
    throw e.pop(), a;
  }, n;
}, "lr");
var cr = /* @__PURE__ */ __name2((e) => {
  const t = [e], r = lr(t);
  return r.values = t, r.Provider = r, Ee.push(r), r;
}, "cr");
var Ee = [];
var wt = /* @__PURE__ */ __name2((e) => {
  const t = [e], r = /* @__PURE__ */ __name2((i) => {
    t.push(i.value);
    let n;
    try {
      n = i.children ? (Array.isArray(i.children) ? new fr("", {}, i.children) : i.children).toString() : "";
    } finally {
      t.pop();
    }
    return n instanceof Promise ? n.then((a) => $(a, a.callbacks)) : $(n);
  }, "r");
  return r.values = t, r.Provider = r, r[bt] = lr(t), Ee.push(r), r;
}, "wt");
var ke = /* @__PURE__ */ __name2((e) => e.values.at(-1), "ke");
var We = { title: [], script: ["src"], style: ["data-href"], link: ["href"], meta: ["name", "httpEquiv", "charset", "itemProp"] };
var pt = {};
var Je = "data-precedence";
var Ie = /* @__PURE__ */ __name2((e) => Array.isArray(e) ? e : [e], "Ie");
var jt = /* @__PURE__ */ new WeakMap();
var Ot = /* @__PURE__ */ __name2((e, t, r, i) => ({ buffer: n, context: a }) => {
  if (!n) return;
  const l = jt.get(a) || {};
  jt.set(a, l);
  const c = l[e] || (l[e] = []);
  let o = false;
  const d = We[e];
  if (d.length > 0) {
    e: for (const [, f] of c) for (const u of d) if (((f == null ? void 0 : f[u]) ?? null) === (r == null ? void 0 : r[u])) {
      o = true;
      break e;
    }
  }
  if (o ? n[0] = n[0].replaceAll(t, "") : d.length > 0 ? c.push([t, r, i]) : c.unshift([t, r, i]), n[0].indexOf("</head>") !== -1) {
    let f;
    if (i === void 0) f = c.map(([u]) => u);
    else {
      const u = [];
      f = c.map(([m, , g]) => {
        let y = u.indexOf(g);
        return y === -1 && (u.push(g), y = u.length - 1), [m, y];
      }).sort((m, g) => m[1] - g[1]).map(([m]) => m);
    }
    f.forEach((u) => {
      n[0] = n[0].replaceAll(u, "");
    }), n[0] = n[0].replace(/(?=<\/head>)/, f.join(""));
  }
}, "Ot");
var He = /* @__PURE__ */ __name2((e, t, r) => $(new F(e, r, Ie(t ?? [])).toString()), "He");
var Fe = /* @__PURE__ */ __name2((e, t, r, i) => {
  if ("itemProp" in r) return He(e, t, r);
  let { precedence: n, blocking: a, ...l } = r;
  n = i ? n ?? "" : void 0, i && (l[Je] = n);
  const c = new F(e, l, Ie(t || [])).toString();
  return c instanceof Promise ? c.then((o) => $(c, [...o.callbacks || [], Ot(e, o, l, n)])) : $(c, [Ot(e, c, l, n)]);
}, "Fe");
var Vr = /* @__PURE__ */ __name2(({ children: e, ...t }) => {
  const r = Et();
  if (r) {
    const i = ke(r);
    if (i === "svg" || i === "head") return new F("title", t, Ie(e ?? []));
  }
  return Fe("title", e, t, false);
}, "Vr");
var Gr = /* @__PURE__ */ __name2(({ children: e, ...t }) => {
  const r = Et();
  return ["src", "async"].some((i) => !t[i]) || r && ke(r) === "head" ? He("script", e, t) : Fe("script", e, t, false);
}, "Gr");
var Kr = /* @__PURE__ */ __name2(({ children: e, ...t }) => ["href", "precedence"].every((r) => r in t) ? (t["data-href"] = t.href, delete t.href, Fe("style", e, t, true)) : He("style", e, t), "Kr");
var Yr = /* @__PURE__ */ __name2(({ children: e, ...t }) => ["onLoad", "onError"].some((r) => r in t) || t.rel === "stylesheet" && (!("precedence" in t) || "disabled" in t) ? He("link", e, t) : Fe("link", e, t, "precedence" in t), "Yr");
var Xr = /* @__PURE__ */ __name2(({ children: e, ...t }) => {
  const r = Et();
  return r && ke(r) === "head" ? He("meta", e, t) : Fe("meta", e, t, false);
}, "Xr");
var or = /* @__PURE__ */ __name2((e, { children: t, ...r }) => new F(e, r, Ie(t ?? [])), "or");
var Zr = /* @__PURE__ */ __name2((e) => (typeof e.action == "function" && (e.action = Ze in e.action ? e.action[Ze] : void 0), or("form", e)), "Zr");
var dr = /* @__PURE__ */ __name2((e, t) => (typeof t.formAction == "function" && (t.formAction = Ze in t.formAction ? t.formAction[Ze] : void 0), or(e, t)), "dr");
var Qr = /* @__PURE__ */ __name2((e) => dr("input", e), "Qr");
var es = /* @__PURE__ */ __name2((e) => dr("button", e), "es");
var nt = Object.freeze(Object.defineProperty({ __proto__: null, button: es, form: Zr, input: Qr, link: Yr, meta: Xr, script: Gr, style: Kr, title: Vr }, Symbol.toStringTag, { value: "Module" }));
var ts = /* @__PURE__ */ new Map([["className", "class"], ["htmlFor", "for"], ["crossOrigin", "crossorigin"], ["httpEquiv", "http-equiv"], ["itemProp", "itemprop"], ["fetchPriority", "fetchpriority"], ["noModule", "nomodule"], ["formAction", "formaction"]]);
var Qe = /* @__PURE__ */ __name2((e) => ts.get(e) || e, "Qe");
var hr = /* @__PURE__ */ __name2((e, t) => {
  for (const [r, i] of Object.entries(e)) {
    const n = r[0] === "-" || !/[A-Z]/.test(r) ? r : r.replace(/[A-Z]/g, (a) => `-${a.toLowerCase()}`);
    t(n, i == null ? null : typeof i == "number" ? n.match(/^(?:a|border-im|column(?:-c|s)|flex(?:$|-[^b])|grid-(?:ar|[^a])|font-w|li|or|sca|st|ta|wido|z)|ty$/) ? `${i}` : `${i}px` : i);
  }
}, "hr");
var Pe = void 0;
var Et = /* @__PURE__ */ __name2(() => Pe, "Et");
var rs = /* @__PURE__ */ __name2((e) => /[A-Z]/.test(e) && e.match(/^(?:al|basel|clip(?:Path|Rule)$|co|do|fill|fl|fo|gl|let|lig|i|marker[EMS]|o|pai|pointe|sh|st[or]|text[^L]|tr|u|ve|w)/) ? e.replace(/([A-Z])/g, "-$1").toLowerCase() : e, "rs");
var ss = ["area", "base", "br", "col", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"];
var is = ["allowfullscreen", "async", "autofocus", "autoplay", "checked", "controls", "default", "defer", "disabled", "download", "formnovalidate", "hidden", "inert", "ismap", "itemscope", "loop", "multiple", "muted", "nomodule", "novalidate", "open", "playsinline", "readonly", "required", "reversed", "selected"];
var At = /* @__PURE__ */ __name2((e, t) => {
  for (let r = 0, i = e.length; r < i; r++) {
    const n = e[r];
    if (typeof n == "string") re(n, t);
    else {
      if (typeof n == "boolean" || n === null || n === void 0) continue;
      n instanceof F ? n.toStringToBuffer(t) : typeof n == "number" || n.isEscaped ? t[0] += n : n instanceof Promise ? t.unshift("", n) : At(n, t);
    }
  }
}, "At");
var F = class {
  static {
    __name(this, "F");
  }
  static {
    __name2(this, "F");
  }
  constructor(e, t, r) {
    x(this, "tag");
    x(this, "props");
    x(this, "key");
    x(this, "children");
    x(this, "isEscaped", true);
    x(this, "localContexts");
    this.tag = e, this.props = t, this.children = r;
  }
  get type() {
    return this.tag;
  }
  get ref() {
    return this.props.ref || null;
  }
  toString() {
    var t, r;
    const e = [""];
    (t = this.localContexts) == null || t.forEach(([i, n]) => {
      i.values.push(n);
    });
    try {
      this.toStringToBuffer(e);
    } finally {
      (r = this.localContexts) == null || r.forEach(([i]) => {
        i.values.pop();
      });
    }
    return e.length === 1 ? "callbacks" in e ? ir($(e[0], e.callbacks)).toString() : e[0] : sr(e, e.callbacks);
  }
  toStringToBuffer(e) {
    const t = this.tag, r = this.props;
    let { children: i } = this;
    e[0] += `<${t}`;
    const n = Pe && ke(Pe) === "svg" ? (a) => rs(Qe(a)) : (a) => Qe(a);
    for (let [a, l] of Object.entries(r)) if (a = n(a), a !== "children") {
      if (a === "style" && typeof l == "object") {
        let c = "";
        hr(l, (o, d) => {
          d != null && (c += `${c ? ";" : ""}${o}:${d}`);
        }), e[0] += ' style="', re(c, e), e[0] += '"';
      } else if (typeof l == "string") e[0] += ` ${a}="`, re(l, e), e[0] += '"';
      else if (l != null) if (typeof l == "number" || l.isEscaped) e[0] += ` ${a}="${l}"`;
      else if (typeof l == "boolean" && is.includes(a)) l && (e[0] += ` ${a}=""`);
      else if (a === "dangerouslySetInnerHTML") {
        if (i.length > 0) throw new Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");
        i = [$(l.__html)];
      } else if (l instanceof Promise) e[0] += ` ${a}="`, e.unshift('"', l);
      else if (typeof l == "function") {
        if (!a.startsWith("on") && a !== "ref") throw new Error(`Invalid prop '${a}' of type 'function' supplied to '${t}'.`);
      } else e[0] += ` ${a}="`, re(l.toString(), e), e[0] += '"';
    }
    if (ss.includes(t) && i.length === 0) {
      e[0] += "/>";
      return;
    }
    e[0] += ">", At(i, e), e[0] += `</${t}>`;
  }
};
var at = class extends F {
  static {
    __name(this, "at");
  }
  static {
    __name2(this, "at");
  }
  toStringToBuffer(e) {
    const { children: t } = this, r = this.tag.call(null, { ...this.props, children: t.length <= 1 ? t[0] : t });
    if (!(typeof r == "boolean" || r == null)) if (r instanceof Promise) if (Ee.length === 0) e.unshift("", r);
    else {
      const i = Ee.map((n) => [n, n.values.at(-1)]);
      e.unshift("", r.then((n) => (n instanceof F && (n.localContexts = i), n)));
    }
    else r instanceof F ? r.toStringToBuffer(e) : typeof r == "number" || r.isEscaped ? (e[0] += r, r.callbacks && (e.callbacks || (e.callbacks = []), e.callbacks.push(...r.callbacks))) : re(r, e);
  }
};
var fr = class extends F {
  static {
    __name(this, "fr");
  }
  static {
    __name2(this, "fr");
  }
  toStringToBuffer(e) {
    At(this.children, e);
  }
};
var Mt = /* @__PURE__ */ __name2((e, t, ...r) => {
  t ?? (t = {}), r.length && (t.children = r.length === 1 ? r[0] : r);
  const i = t.key;
  delete t.key;
  const n = ze(e, t, r);
  return n.key = i, n;
}, "Mt");
var Nt = false;
var ze = /* @__PURE__ */ __name2((e, t, r) => {
  if (!Nt) {
    for (const i in pt) nt[i][bt] = pt[i];
    Nt = true;
  }
  return typeof e == "function" ? new at(e, t, r) : nt[e] ? new at(nt[e], t, r) : e === "svg" || e === "head" ? (Pe || (Pe = wt("")), new F(e, t, [new at(Pe, { value: e }, r)])) : new F(e, t, r);
}, "ze");
var q = /* @__PURE__ */ __name2(({ children: e }) => new fr("", { children: e }, Array.isArray(e) ? e : e ? [e] : []), "q");
function s(e, t, r) {
  let i;
  if (!t || !("children" in t)) i = ze(e, t, []);
  else {
    const n = t.children;
    i = Array.isArray(n) ? ze(e, t, n) : ze(e, t, [n]);
  }
  return i.key = r, i;
}
__name(s, "s");
__name2(s, "s");
var Dt = /* @__PURE__ */ __name2((e, t, r) => (i, n) => {
  let a = -1;
  return l(0);
  async function l(c) {
    if (c <= a) throw new Error("next() called multiple times");
    a = c;
    let o, d = false, f;
    if (e[c] ? (f = e[c][0][0], i.req.routeIndex = c) : f = c === e.length && n || void 0, f) try {
      o = await f(i, () => l(c + 1));
    } catch (u) {
      if (u instanceof Error && t) i.error = u, o = await t(u, i), d = true;
      else throw u;
    }
    else i.finalized === false && r && (o = await r(i));
    return o && (i.finalized === false || d) && (i.res = o), i;
  }
  __name(l, "l");
  __name2(l, "l");
}, "Dt");
var ns = Symbol();
var as = /* @__PURE__ */ __name2(async (e, t = /* @__PURE__ */ Object.create(null)) => {
  const { all: r = false, dot: i = false } = t, a = (e instanceof vr ? e.raw.headers : e.headers).get("Content-Type");
  return a != null && a.startsWith("multipart/form-data") || a != null && a.startsWith("application/x-www-form-urlencoded") ? ls(e, { all: r, dot: i }) : {};
}, "as");
async function ls(e, t) {
  const r = await e.formData();
  return r ? cs(r, t) : {};
}
__name(ls, "ls");
__name2(ls, "ls");
function cs(e, t) {
  const r = /* @__PURE__ */ Object.create(null);
  return e.forEach((i, n) => {
    t.all || n.endsWith("[]") ? os(r, n, i) : r[n] = i;
  }), t.dot && Object.entries(r).forEach(([i, n]) => {
    i.includes(".") && (ds(r, i, n), delete r[i]);
  }), r;
}
__name(cs, "cs");
__name2(cs, "cs");
var os = /* @__PURE__ */ __name2((e, t, r) => {
  e[t] !== void 0 ? Array.isArray(e[t]) ? e[t].push(r) : e[t] = [e[t], r] : t.endsWith("[]") ? e[t] = [r] : e[t] = r;
}, "os");
var ds = /* @__PURE__ */ __name2((e, t, r) => {
  let i = e;
  const n = t.split(".");
  n.forEach((a, l) => {
    l === n.length - 1 ? i[a] = r : ((!i[a] || typeof i[a] != "object" || Array.isArray(i[a]) || i[a] instanceof File) && (i[a] = /* @__PURE__ */ Object.create(null)), i = i[a]);
  });
}, "ds");
var ur = /* @__PURE__ */ __name2((e) => {
  const t = e.split("/");
  return t[0] === "" && t.shift(), t;
}, "ur");
var hs = /* @__PURE__ */ __name2((e) => {
  const { groups: t, path: r } = fs(e), i = ur(r);
  return us(i, t);
}, "hs");
var fs = /* @__PURE__ */ __name2((e) => {
  const t = [];
  return e = e.replace(/\{[^}]+\}/g, (r, i) => {
    const n = `@${i}`;
    return t.push([n, r]), n;
  }), { groups: t, path: e };
}, "fs");
var us = /* @__PURE__ */ __name2((e, t) => {
  for (let r = t.length - 1; r >= 0; r--) {
    const [i] = t[r];
    for (let n = e.length - 1; n >= 0; n--) if (e[n].includes(i)) {
      e[n] = e[n].replace(i, t[r][1]);
      break;
    }
  }
  return e;
}, "us");
var Ue = {};
var ms = /* @__PURE__ */ __name2((e, t) => {
  if (e === "*") return "*";
  const r = e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (r) {
    const i = `${e}#${t}`;
    return Ue[i] || (r[2] ? Ue[i] = t && t[0] !== ":" && t[0] !== "*" ? [i, r[1], new RegExp(`^${r[2]}(?=/${t})`)] : [e, r[1], new RegExp(`^${r[2]}$`)] : Ue[i] = [e, r[1], true]), Ue[i];
  }
  return null;
}, "ms");
var kt = /* @__PURE__ */ __name2((e, t) => {
  try {
    return t(e);
  } catch {
    return e.replace(/(?:%[0-9A-Fa-f]{2})+/g, (r) => {
      try {
        return t(r);
      } catch {
        return r;
      }
    });
  }
}, "kt");
var ps = /* @__PURE__ */ __name2((e) => kt(e, decodeURI), "ps");
var mr = /* @__PURE__ */ __name2((e) => {
  const t = e.url, r = t.indexOf("/", t.indexOf(":") + 4);
  let i = r;
  for (; i < t.length; i++) {
    const n = t.charCodeAt(i);
    if (n === 37) {
      const a = t.indexOf("?", i), l = t.slice(r, a === -1 ? void 0 : a);
      return ps(l.includes("%25") ? l.replace(/%25/g, "%2525") : l);
    } else if (n === 63) break;
  }
  return t.slice(r, i);
}, "mr");
var gs = /* @__PURE__ */ __name2((e) => {
  const t = mr(e);
  return t.length > 1 && t.at(-1) === "/" ? t.slice(0, -1) : t;
}, "gs");
var me = /* @__PURE__ */ __name2((e, t, ...r) => (r.length && (t = me(t, ...r)), `${(e == null ? void 0 : e[0]) === "/" ? "" : "/"}${e}${t === "/" ? "" : `${(e == null ? void 0 : e.at(-1)) === "/" ? "" : "/"}${(t == null ? void 0 : t[0]) === "/" ? t.slice(1) : t}`}`), "me");
var pr = /* @__PURE__ */ __name2((e) => {
  if (e.charCodeAt(e.length - 1) !== 63 || !e.includes(":")) return null;
  const t = e.split("/"), r = [];
  let i = "";
  return t.forEach((n) => {
    if (n !== "" && !/\:/.test(n)) i += "/" + n;
    else if (/\:/.test(n)) if (/\?/.test(n)) {
      r.length === 0 && i === "" ? r.push("/") : r.push(i);
      const a = n.replace("?", "");
      i += "/" + a, r.push(i);
    } else i += "/" + n;
  }), r.filter((n, a, l) => l.indexOf(n) === a);
}, "pr");
var lt = /* @__PURE__ */ __name2((e) => /[%+]/.test(e) ? (e.indexOf("+") !== -1 && (e = e.replace(/\+/g, " ")), e.indexOf("%") !== -1 ? kt(e, xr) : e) : e, "lt");
var gr = /* @__PURE__ */ __name2((e, t, r) => {
  let i;
  if (!r && t && !/[%+]/.test(t)) {
    let l = e.indexOf(`?${t}`, 8);
    for (l === -1 && (l = e.indexOf(`&${t}`, 8)); l !== -1; ) {
      const c = e.charCodeAt(l + t.length + 1);
      if (c === 61) {
        const o = l + t.length + 2, d = e.indexOf("&", o);
        return lt(e.slice(o, d === -1 ? void 0 : d));
      } else if (c == 38 || isNaN(c)) return "";
      l = e.indexOf(`&${t}`, l + 1);
    }
    if (i = /[%+]/.test(e), !i) return;
  }
  const n = {};
  i ?? (i = /[%+]/.test(e));
  let a = e.indexOf("?", 8);
  for (; a !== -1; ) {
    const l = e.indexOf("&", a + 1);
    let c = e.indexOf("=", a);
    c > l && l !== -1 && (c = -1);
    let o = e.slice(a + 1, c === -1 ? l === -1 ? void 0 : l : c);
    if (i && (o = lt(o)), a = l, o === "") continue;
    let d;
    c === -1 ? d = "" : (d = e.slice(c + 1, l === -1 ? void 0 : l), i && (d = lt(d))), r ? (n[o] && Array.isArray(n[o]) || (n[o] = []), n[o].push(d)) : n[o] ?? (n[o] = d);
  }
  return t ? n[t] : n;
}, "gr");
var xs = gr;
var vs = /* @__PURE__ */ __name2((e, t) => gr(e, t, true), "vs");
var xr = decodeURIComponent;
var Lt = /* @__PURE__ */ __name2((e) => kt(e, xr), "Lt");
var xe;
var L;
var G;
var yr;
var br;
var gt;
var Y;
var Vt;
var vr = (Vt = class {
  static {
    __name(this, "Vt");
  }
  static {
    __name2(this, "Vt");
  }
  constructor(e, t = "/", r = [[]]) {
    E(this, G);
    x(this, "raw");
    E(this, xe);
    E(this, L);
    x(this, "routeIndex", 0);
    x(this, "path");
    x(this, "bodyCache", {});
    E(this, Y, (e2) => {
      const { bodyCache: t2, raw: r2 } = this, i = t2[e2];
      if (i) return i;
      const n = Object.keys(t2)[0];
      return n ? t2[n].then((a) => (n === "json" && (a = JSON.stringify(a)), new Response(a)[e2]())) : t2[e2] = r2[e2]();
    });
    this.raw = e, this.path = t, b(this, L, r), b(this, xe, {});
  }
  param(e) {
    return e ? C(this, G, yr).call(this, e) : C(this, G, br).call(this);
  }
  query(e) {
    return xs(this.url, e);
  }
  queries(e) {
    return vs(this.url, e);
  }
  header(e) {
    if (e) return this.raw.headers.get(e) ?? void 0;
    const t = {};
    return this.raw.headers.forEach((r, i) => {
      t[i] = r;
    }), t;
  }
  async parseBody(e) {
    var t;
    return (t = this.bodyCache).parsedBody ?? (t.parsedBody = await as(this, e));
  }
  json() {
    return h(this, Y).call(this, "text").then((e) => JSON.parse(e));
  }
  text() {
    return h(this, Y).call(this, "text");
  }
  arrayBuffer() {
    return h(this, Y).call(this, "arrayBuffer");
  }
  blob() {
    return h(this, Y).call(this, "blob");
  }
  formData() {
    return h(this, Y).call(this, "formData");
  }
  addValidatedData(e, t) {
    h(this, xe)[e] = t;
  }
  valid(e) {
    return h(this, xe)[e];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [ns]() {
    return h(this, L);
  }
  get matchedRoutes() {
    return h(this, L)[0].map(([[, e]]) => e);
  }
  get routePath() {
    return h(this, L)[0].map(([[, e]]) => e)[this.routeIndex].path;
  }
}, xe = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakSet(), yr = /* @__PURE__ */ __name2(function(e) {
  const t = h(this, L)[0][this.routeIndex][1][e], r = C(this, G, gt).call(this, t);
  return r && /\%/.test(r) ? Lt(r) : r;
}, "yr"), br = /* @__PURE__ */ __name2(function() {
  const e = {}, t = Object.keys(h(this, L)[0][this.routeIndex][1]);
  for (const r of t) {
    const i = C(this, G, gt).call(this, h(this, L)[0][this.routeIndex][1][r]);
    i !== void 0 && (e[r] = /\%/.test(i) ? Lt(i) : i);
  }
  return e;
}, "br"), gt = /* @__PURE__ */ __name2(function(e) {
  return h(this, L)[1] ? h(this, L)[1][e] : e;
}, "gt"), Y = /* @__PURE__ */ new WeakMap(), Vt);
var ys = "text/plain; charset=UTF-8";
var ct = /* @__PURE__ */ __name2((e, t) => ({ "Content-Type": e, ...t }), "ct");
var Me;
var Ne;
var W;
var ve;
var J;
var D;
var De;
var ye;
var be;
var ae;
var Le;
var $e;
var X;
var pe;
var Gt;
var bs = (Gt = class {
  static {
    __name(this, "Gt");
  }
  static {
    __name2(this, "Gt");
  }
  constructor(e, t) {
    E(this, X);
    E(this, Me);
    E(this, Ne);
    x(this, "env", {});
    E(this, W);
    x(this, "finalized", false);
    x(this, "error");
    E(this, ve);
    E(this, J);
    E(this, D);
    E(this, De);
    E(this, ye);
    E(this, be);
    E(this, ae);
    E(this, Le);
    E(this, $e);
    x(this, "render", (...e2) => (h(this, ye) ?? b(this, ye, (t2) => this.html(t2)), h(this, ye).call(this, ...e2)));
    x(this, "setLayout", (e2) => b(this, De, e2));
    x(this, "getLayout", () => h(this, De));
    x(this, "setRenderer", (e2) => {
      b(this, ye, e2);
    });
    x(this, "header", (e2, t2, r) => {
      this.finalized && b(this, D, new Response(h(this, D).body, h(this, D)));
      const i = h(this, D) ? h(this, D).headers : h(this, ae) ?? b(this, ae, new Headers());
      t2 === void 0 ? i.delete(e2) : r != null && r.append ? i.append(e2, t2) : i.set(e2, t2);
    });
    x(this, "status", (e2) => {
      b(this, ve, e2);
    });
    x(this, "set", (e2, t2) => {
      h(this, W) ?? b(this, W, /* @__PURE__ */ new Map()), h(this, W).set(e2, t2);
    });
    x(this, "get", (e2) => h(this, W) ? h(this, W).get(e2) : void 0);
    x(this, "newResponse", (...e2) => C(this, X, pe).call(this, ...e2));
    x(this, "body", (e2, t2, r) => C(this, X, pe).call(this, e2, t2, r));
    x(this, "text", (e2, t2, r) => !h(this, ae) && !h(this, ve) && !t2 && !r && !this.finalized ? new Response(e2) : C(this, X, pe).call(this, e2, t2, ct(ys, r)));
    x(this, "json", (e2, t2, r) => C(this, X, pe).call(this, JSON.stringify(e2), t2, ct("application/json", r)));
    x(this, "html", (e2, t2, r) => {
      const i = /* @__PURE__ */ __name2((n) => C(this, X, pe).call(this, n, t2, ct("text/html; charset=UTF-8", r)), "i");
      return typeof e2 == "object" ? nr(e2, rr.Stringify, false, {}).then(i) : i(e2);
    });
    x(this, "redirect", (e2, t2) => {
      const r = String(e2);
      return this.header("Location", /[^\x00-\xFF]/.test(r) ? encodeURI(r) : r), this.newResponse(null, t2 ?? 302);
    });
    x(this, "notFound", () => (h(this, be) ?? b(this, be, () => new Response()), h(this, be).call(this, this)));
    b(this, Me, e), t && (b(this, J, t.executionCtx), this.env = t.env, b(this, be, t.notFoundHandler), b(this, $e, t.path), b(this, Le, t.matchResult));
  }
  get req() {
    return h(this, Ne) ?? b(this, Ne, new vr(h(this, Me), h(this, $e), h(this, Le))), h(this, Ne);
  }
  get event() {
    if (h(this, J) && "respondWith" in h(this, J)) return h(this, J);
    throw Error("This context has no FetchEvent");
  }
  get executionCtx() {
    if (h(this, J)) return h(this, J);
    throw Error("This context has no ExecutionContext");
  }
  get res() {
    return h(this, D) || b(this, D, new Response(null, { headers: h(this, ae) ?? b(this, ae, new Headers()) }));
  }
  set res(e) {
    if (h(this, D) && e) {
      e = new Response(e.body, e);
      for (const [t, r] of h(this, D).headers.entries()) if (t !== "content-type") if (t === "set-cookie") {
        const i = h(this, D).headers.getSetCookie();
        e.headers.delete("set-cookie");
        for (const n of i) e.headers.append("set-cookie", n);
      } else e.headers.set(t, r);
    }
    b(this, D, e), this.finalized = true;
  }
  get var() {
    return h(this, W) ? Object.fromEntries(h(this, W)) : {};
  }
}, Me = /* @__PURE__ */ new WeakMap(), Ne = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakMap(), D = /* @__PURE__ */ new WeakMap(), De = /* @__PURE__ */ new WeakMap(), ye = /* @__PURE__ */ new WeakMap(), be = /* @__PURE__ */ new WeakMap(), ae = /* @__PURE__ */ new WeakMap(), Le = /* @__PURE__ */ new WeakMap(), $e = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakSet(), pe = /* @__PURE__ */ __name2(function(e, t, r) {
  const i = h(this, D) ? new Headers(h(this, D).headers) : h(this, ae) ?? new Headers();
  if (typeof t == "object" && "headers" in t) {
    const a = t.headers instanceof Headers ? t.headers : new Headers(t.headers);
    for (const [l, c] of a) l.toLowerCase() === "set-cookie" ? i.append(l, c) : i.set(l, c);
  }
  if (r) for (const [a, l] of Object.entries(r)) if (typeof l == "string") i.set(a, l);
  else {
    i.delete(a);
    for (const c of l) i.append(a, c);
  }
  const n = typeof t == "number" ? t : (t == null ? void 0 : t.status) ?? h(this, ve);
  return new Response(e, { status: n, headers: i });
}, "pe"), Gt);
var R = "ALL";
var ws = "all";
var Es = ["get", "post", "put", "delete", "options", "patch"];
var wr = "Can not add a route since the matcher is already built.";
var Er = class extends Error {
  static {
    __name(this, "Er");
  }
  static {
    __name2(this, "Er");
  }
};
var As = "__COMPOSED_HANDLER";
var ks = /* @__PURE__ */ __name2((e) => e.text("404 Not Found", 404), "ks");
var $t = /* @__PURE__ */ __name2((e, t) => {
  if ("getResponse" in e) {
    const r = e.getResponse();
    return t.newResponse(r.body, r);
  }
  return console.error(e), t.text("Internal Server Error", 500);
}, "$t");
var _;
var P;
var kr;
var I;
var ie;
var Ve;
var Ge;
var Kt;
var Ar = (Kt = class {
  static {
    __name(this, "Kt");
  }
  static {
    __name2(this, "Kt");
  }
  constructor(t = {}) {
    E(this, P);
    x(this, "get");
    x(this, "post");
    x(this, "put");
    x(this, "delete");
    x(this, "options");
    x(this, "patch");
    x(this, "all");
    x(this, "on");
    x(this, "use");
    x(this, "router");
    x(this, "getPath");
    x(this, "_basePath", "/");
    E(this, _, "/");
    x(this, "routes", []);
    E(this, I, ks);
    x(this, "errorHandler", $t);
    x(this, "onError", (t2) => (this.errorHandler = t2, this));
    x(this, "notFound", (t2) => (b(this, I, t2), this));
    x(this, "fetch", (t2, ...r) => C(this, P, Ge).call(this, t2, r[1], r[0], t2.method));
    x(this, "request", (t2, r, i2, n2) => t2 instanceof Request ? this.fetch(r ? new Request(t2, r) : t2, i2, n2) : (t2 = t2.toString(), this.fetch(new Request(/^https?:\/\//.test(t2) ? t2 : `http://localhost${me("/", t2)}`, r), i2, n2)));
    x(this, "fire", () => {
      addEventListener("fetch", (t2) => {
        t2.respondWith(C(this, P, Ge).call(this, t2.request, t2, void 0, t2.request.method));
      });
    });
    [...Es, ws].forEach((a) => {
      this[a] = (l, ...c) => (typeof l == "string" ? b(this, _, l) : C(this, P, ie).call(this, a, h(this, _), l), c.forEach((o) => {
        C(this, P, ie).call(this, a, h(this, _), o);
      }), this);
    }), this.on = (a, l, ...c) => {
      for (const o of [l].flat()) {
        b(this, _, o);
        for (const d of [a].flat()) c.map((f) => {
          C(this, P, ie).call(this, d.toUpperCase(), h(this, _), f);
        });
      }
      return this;
    }, this.use = (a, ...l) => (typeof a == "string" ? b(this, _, a) : (b(this, _, "*"), l.unshift(a)), l.forEach((c) => {
      C(this, P, ie).call(this, R, h(this, _), c);
    }), this);
    const { strict: i, ...n } = t;
    Object.assign(this, n), this.getPath = i ?? true ? t.getPath ?? mr : gs;
  }
  route(t, r) {
    const i = this.basePath(t);
    return r.routes.map((n) => {
      var l;
      let a;
      r.errorHandler === $t ? a = n.handler : (a = /* @__PURE__ */ __name2(async (c, o) => (await Dt([], r.errorHandler)(c, () => n.handler(c, o))).res, "a"), a[As] = n.handler), C(l = i, P, ie).call(l, n.method, n.path, a);
    }), this;
  }
  basePath(t) {
    const r = C(this, P, kr).call(this);
    return r._basePath = me(this._basePath, t), r;
  }
  mount(t, r, i) {
    let n, a;
    i && (typeof i == "function" ? a = i : (a = i.optionHandler, i.replaceRequest === false ? n = /* @__PURE__ */ __name2((o) => o, "n") : n = i.replaceRequest));
    const l = a ? (o) => {
      const d = a(o);
      return Array.isArray(d) ? d : [d];
    } : (o) => {
      let d;
      try {
        d = o.executionCtx;
      } catch {
      }
      return [o.env, d];
    };
    n || (n = (() => {
      const o = me(this._basePath, t), d = o === "/" ? 0 : o.length;
      return (f) => {
        const u = new URL(f.url);
        return u.pathname = u.pathname.slice(d) || "/", new Request(u, f);
      };
    })());
    const c = /* @__PURE__ */ __name2(async (o, d) => {
      const f = await r(n(o.req.raw), ...l(o));
      if (f) return f;
      await d();
    }, "c");
    return C(this, P, ie).call(this, R, me(t, "*"), c), this;
  }
}, _ = /* @__PURE__ */ new WeakMap(), P = /* @__PURE__ */ new WeakSet(), kr = /* @__PURE__ */ __name2(function() {
  const t = new Ar({ router: this.router, getPath: this.getPath });
  return t.errorHandler = this.errorHandler, b(t, I, h(this, I)), t.routes = this.routes, t;
}, "kr"), I = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ __name2(function(t, r, i) {
  t = t.toUpperCase(), r = me(this._basePath, r);
  const n = { basePath: this._basePath, path: r, method: t, handler: i };
  this.router.add(t, r, [i, n]), this.routes.push(n);
}, "ie"), Ve = /* @__PURE__ */ __name2(function(t, r) {
  if (t instanceof Error) return this.errorHandler(t, r);
  throw t;
}, "Ve"), Ge = /* @__PURE__ */ __name2(function(t, r, i, n) {
  if (n === "HEAD") return (async () => new Response(null, await C(this, P, Ge).call(this, t, r, i, "GET")))();
  const a = this.getPath(t, { env: i }), l = this.router.match(n, a), c = new bs(t, { path: a, matchResult: l, env: i, executionCtx: r, notFoundHandler: h(this, I) });
  if (l[0].length === 1) {
    let d;
    try {
      d = l[0][0][0][0](c, async () => {
        c.res = await h(this, I).call(this, c);
      });
    } catch (f) {
      return C(this, P, Ve).call(this, f, c);
    }
    return d instanceof Promise ? d.then((f) => f || (c.finalized ? c.res : h(this, I).call(this, c))).catch((f) => C(this, P, Ve).call(this, f, c)) : d ?? h(this, I).call(this, c);
  }
  const o = Dt(l[0], this.errorHandler, h(this, I));
  return (async () => {
    try {
      const d = await o(c);
      if (!d.finalized) throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
      return d.res;
    } catch (d) {
      return C(this, P, Ve).call(this, d, c);
    }
  })();
}, "Ge"), Kt);
var Cr = [];
function Cs(e, t) {
  const r = this.buildAllMatchers(), i = /* @__PURE__ */ __name2((n, a) => {
    const l = r[n] || r[R], c = l[2][a];
    if (c) return c;
    const o = a.match(l[0]);
    if (!o) return [[], Cr];
    const d = o.indexOf("", 1);
    return [l[1][d], o];
  }, "i");
  return this.match = i, i(e, t);
}
__name(Cs, "Cs");
__name2(Cs, "Cs");
var et = "[^/]+";
var Te = ".*";
var Re = "(?:|/.*)";
var ge = Symbol();
var Ss = new Set(".\\+*[^]$()");
function Ts(e, t) {
  return e.length === 1 ? t.length === 1 ? e < t ? -1 : 1 : -1 : t.length === 1 || e === Te || e === Re ? 1 : t === Te || t === Re ? -1 : e === et ? 1 : t === et ? -1 : e.length === t.length ? e < t ? -1 : 1 : t.length - e.length;
}
__name(Ts, "Ts");
__name2(Ts, "Ts");
var le;
var ce;
var H;
var Yt;
var xt = (Yt = class {
  static {
    __name(this, "Yt");
  }
  static {
    __name2(this, "Yt");
  }
  constructor() {
    E(this, le);
    E(this, ce);
    E(this, H, /* @__PURE__ */ Object.create(null));
  }
  insert(t, r, i, n, a) {
    if (t.length === 0) {
      if (h(this, le) !== void 0) throw ge;
      if (a) return;
      b(this, le, r);
      return;
    }
    const [l, ...c] = t, o = l === "*" ? c.length === 0 ? ["", "", Te] : ["", "", et] : l === "/*" ? ["", "", Re] : l.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let d;
    if (o) {
      const f = o[1];
      let u = o[2] || et;
      if (f && o[2] && (u === ".*" || (u = u.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:"), /\((?!\?:)/.test(u)))) throw ge;
      if (d = h(this, H)[u], !d) {
        if (Object.keys(h(this, H)).some((m) => m !== Te && m !== Re)) throw ge;
        if (a) return;
        d = h(this, H)[u] = new xt(), f !== "" && b(d, ce, n.varIndex++);
      }
      !a && f !== "" && i.push([f, h(d, ce)]);
    } else if (d = h(this, H)[l], !d) {
      if (Object.keys(h(this, H)).some((f) => f.length > 1 && f !== Te && f !== Re)) throw ge;
      if (a) return;
      d = h(this, H)[l] = new xt();
    }
    d.insert(c, r, i, n, a);
  }
  buildRegExpStr() {
    const r = Object.keys(h(this, H)).sort(Ts).map((i) => {
      const n = h(this, H)[i];
      return (typeof h(n, ce) == "number" ? `(${i})@${h(n, ce)}` : Ss.has(i) ? `\\${i}` : i) + n.buildRegExpStr();
    });
    return typeof h(this, le) == "number" && r.unshift(`#${h(this, le)}`), r.length === 0 ? "" : r.length === 1 ? r[0] : "(?:" + r.join("|") + ")";
  }
}, le = /* @__PURE__ */ new WeakMap(), ce = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), Yt);
var tt;
var _e;
var Xt;
var Rs = (Xt = class {
  static {
    __name(this, "Xt");
  }
  static {
    __name2(this, "Xt");
  }
  constructor() {
    E(this, tt, { varIndex: 0 });
    E(this, _e, new xt());
  }
  insert(e, t, r) {
    const i = [], n = [];
    for (let l = 0; ; ) {
      let c = false;
      if (e = e.replace(/\{[^}]+\}/g, (o) => {
        const d = `@\\${l}`;
        return n[l] = [d, o], l++, c = true, d;
      }), !c) break;
    }
    const a = e.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let l = n.length - 1; l >= 0; l--) {
      const [c] = n[l];
      for (let o = a.length - 1; o >= 0; o--) if (a[o].indexOf(c) !== -1) {
        a[o] = a[o].replace(c, n[l][1]);
        break;
      }
    }
    return h(this, _e).insert(a, t, i, h(this, tt), r), i;
  }
  buildRegExp() {
    let e = h(this, _e).buildRegExpStr();
    if (e === "") return [/^$/, [], []];
    let t = 0;
    const r = [], i = [];
    return e = e.replace(/#(\d+)|@(\d+)|\.\*\$/g, (n, a, l) => a !== void 0 ? (r[++t] = Number(a), "$()") : (l !== void 0 && (i[Number(l)] = ++t), "")), [new RegExp(`^${e}`), r, i];
  }
}, tt = /* @__PURE__ */ new WeakMap(), _e = /* @__PURE__ */ new WeakMap(), Xt);
var Ps = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var Ke = /* @__PURE__ */ Object.create(null);
function Sr(e) {
  return Ke[e] ?? (Ke[e] = new RegExp(e === "*" ? "" : `^${e.replace(/\/\*$|([.\\+*[^\]$()])/g, (t, r) => r ? `\\${r}` : "(?:|/.*)")}$`));
}
__name(Sr, "Sr");
__name2(Sr, "Sr");
function js() {
  Ke = /* @__PURE__ */ Object.create(null);
}
__name(js, "js");
__name2(js, "js");
function Os(e) {
  var d;
  const t = new Rs(), r = [];
  if (e.length === 0) return Ps;
  const i = e.map((f) => [!/\*|\/:/.test(f[0]), ...f]).sort(([f, u], [m, g]) => f ? 1 : m ? -1 : u.length - g.length), n = /* @__PURE__ */ Object.create(null);
  for (let f = 0, u = -1, m = i.length; f < m; f++) {
    const [g, y, p] = i[f];
    g ? n[y] = [p.map(([w]) => [w, /* @__PURE__ */ Object.create(null)]), Cr] : u++;
    let v;
    try {
      v = t.insert(y, u, g);
    } catch (w) {
      throw w === ge ? new Er(y) : w;
    }
    g || (r[u] = p.map(([w, A]) => {
      const S = /* @__PURE__ */ Object.create(null);
      for (A -= 1; A >= 0; A--) {
        const [k, M] = v[A];
        S[k] = M;
      }
      return [w, S];
    }));
  }
  const [a, l, c] = t.buildRegExp();
  for (let f = 0, u = r.length; f < u; f++) for (let m = 0, g = r[f].length; m < g; m++) {
    const y = (d = r[f][m]) == null ? void 0 : d[1];
    if (!y) continue;
    const p = Object.keys(y);
    for (let v = 0, w = p.length; v < w; v++) y[p[v]] = c[y[p[v]]];
  }
  const o = [];
  for (const f in l) o[f] = r[l[f]];
  return [a, o, n];
}
__name(Os, "Os");
__name2(Os, "Os");
function fe(e, t) {
  if (e) {
    for (const r of Object.keys(e).sort((i, n) => n.length - i.length)) if (Sr(r).test(t)) return [...e[r]];
  }
}
__name(fe, "fe");
__name2(fe, "fe");
var Z;
var Q;
var rt;
var Tr;
var Zt;
var Ms = (Zt = class {
  static {
    __name(this, "Zt");
  }
  static {
    __name2(this, "Zt");
  }
  constructor() {
    E(this, rt);
    x(this, "name", "RegExpRouter");
    E(this, Z);
    E(this, Q);
    x(this, "match", Cs);
    b(this, Z, { [R]: /* @__PURE__ */ Object.create(null) }), b(this, Q, { [R]: /* @__PURE__ */ Object.create(null) });
  }
  add(e, t, r) {
    var c;
    const i = h(this, Z), n = h(this, Q);
    if (!i || !n) throw new Error(wr);
    i[e] || [i, n].forEach((o) => {
      o[e] = /* @__PURE__ */ Object.create(null), Object.keys(o[R]).forEach((d) => {
        o[e][d] = [...o[R][d]];
      });
    }), t === "/*" && (t = "*");
    const a = (t.match(/\/:/g) || []).length;
    if (/\*$/.test(t)) {
      const o = Sr(t);
      e === R ? Object.keys(i).forEach((d) => {
        var f;
        (f = i[d])[t] || (f[t] = fe(i[d], t) || fe(i[R], t) || []);
      }) : (c = i[e])[t] || (c[t] = fe(i[e], t) || fe(i[R], t) || []), Object.keys(i).forEach((d) => {
        (e === R || e === d) && Object.keys(i[d]).forEach((f) => {
          o.test(f) && i[d][f].push([r, a]);
        });
      }), Object.keys(n).forEach((d) => {
        (e === R || e === d) && Object.keys(n[d]).forEach((f) => o.test(f) && n[d][f].push([r, a]));
      });
      return;
    }
    const l = pr(t) || [t];
    for (let o = 0, d = l.length; o < d; o++) {
      const f = l[o];
      Object.keys(n).forEach((u) => {
        var m;
        (e === R || e === u) && ((m = n[u])[f] || (m[f] = [...fe(i[u], f) || fe(i[R], f) || []]), n[u][f].push([r, a - d + o + 1]));
      });
    }
  }
  buildAllMatchers() {
    const e = /* @__PURE__ */ Object.create(null);
    return Object.keys(h(this, Q)).concat(Object.keys(h(this, Z))).forEach((t) => {
      e[t] || (e[t] = C(this, rt, Tr).call(this, t));
    }), b(this, Z, b(this, Q, void 0)), js(), e;
  }
}, Z = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap(), rt = /* @__PURE__ */ new WeakSet(), Tr = /* @__PURE__ */ __name2(function(e) {
  const t = [];
  let r = e === R;
  return [h(this, Z), h(this, Q)].forEach((i) => {
    const n = i[e] ? Object.keys(i[e]).map((a) => [a, i[e][a]]) : [];
    n.length !== 0 ? (r || (r = true), t.push(...n)) : e !== R && t.push(...Object.keys(i[R]).map((a) => [a, i[R][a]]));
  }), r ? Os(t) : null;
}, "Tr"), Zt);
var ee;
var z;
var Qt;
var Ns = (Qt = class {
  static {
    __name(this, "Qt");
  }
  static {
    __name2(this, "Qt");
  }
  constructor(e) {
    x(this, "name", "SmartRouter");
    E(this, ee, []);
    E(this, z, []);
    b(this, ee, e.routers);
  }
  add(e, t, r) {
    if (!h(this, z)) throw new Error(wr);
    h(this, z).push([e, t, r]);
  }
  match(e, t) {
    if (!h(this, z)) throw new Error("Fatal error");
    const r = h(this, ee), i = h(this, z), n = r.length;
    let a = 0, l;
    for (; a < n; a++) {
      const c = r[a];
      try {
        for (let o = 0, d = i.length; o < d; o++) c.add(...i[o]);
        l = c.match(e, t);
      } catch (o) {
        if (o instanceof Er) continue;
        throw o;
      }
      this.match = c.match.bind(c), b(this, ee, [c]), b(this, z, void 0);
      break;
    }
    if (a === n) throw new Error("Fatal error");
    return this.name = `SmartRouter + ${this.activeRouter.name}`, l;
  }
  get activeRouter() {
    if (h(this, z) || h(this, ee).length !== 1) throw new Error("No active router has been determined yet.");
    return h(this, ee)[0];
  }
}, ee = /* @__PURE__ */ new WeakMap(), z = /* @__PURE__ */ new WeakMap(), Qt);
var Ce = /* @__PURE__ */ Object.create(null);
var te;
var N;
var oe;
var we;
var j;
var V;
var ne;
var er;
var Rr = (er = class {
  static {
    __name(this, "er");
  }
  static {
    __name2(this, "er");
  }
  constructor(e, t, r) {
    E(this, V);
    E(this, te);
    E(this, N);
    E(this, oe);
    E(this, we, 0);
    E(this, j, Ce);
    if (b(this, N, r || /* @__PURE__ */ Object.create(null)), b(this, te, []), e && t) {
      const i = /* @__PURE__ */ Object.create(null);
      i[e] = { handler: t, possibleKeys: [], score: 0 }, b(this, te, [i]);
    }
    b(this, oe, []);
  }
  insert(e, t, r) {
    b(this, we, ++Rt(this, we)._);
    let i = this;
    const n = hs(t), a = [];
    for (let l = 0, c = n.length; l < c; l++) {
      const o = n[l], d = n[l + 1], f = ms(o, d), u = Array.isArray(f) ? f[0] : o;
      if (u in h(i, N)) {
        i = h(i, N)[u], f && a.push(f[1]);
        continue;
      }
      h(i, N)[u] = new Rr(), f && (h(i, oe).push(f), a.push(f[1])), i = h(i, N)[u];
    }
    return h(i, te).push({ [e]: { handler: r, possibleKeys: a.filter((l, c, o) => o.indexOf(l) === c), score: h(this, we) } }), i;
  }
  search(e, t) {
    var c;
    const r = [];
    b(this, j, Ce);
    let n = [this];
    const a = ur(t), l = [];
    for (let o = 0, d = a.length; o < d; o++) {
      const f = a[o], u = o === d - 1, m = [];
      for (let g = 0, y = n.length; g < y; g++) {
        const p = n[g], v = h(p, N)[f];
        v && (b(v, j, h(p, j)), u ? (h(v, N)["*"] && r.push(...C(this, V, ne).call(this, h(v, N)["*"], e, h(p, j))), r.push(...C(this, V, ne).call(this, v, e, h(p, j)))) : m.push(v));
        for (let w = 0, A = h(p, oe).length; w < A; w++) {
          const S = h(p, oe)[w], k = h(p, j) === Ce ? {} : { ...h(p, j) };
          if (S === "*") {
            const K = h(p, N)["*"];
            K && (r.push(...C(this, V, ne).call(this, K, e, h(p, j))), b(K, j, k), m.push(K));
            continue;
          }
          const [M, he, se] = S;
          if (!f && !(se instanceof RegExp)) continue;
          const U = h(p, N)[M], qr = a.slice(o).join("/");
          if (se instanceof RegExp) {
            const K = se.exec(qr);
            if (K) {
              if (k[he] = K[0], r.push(...C(this, V, ne).call(this, U, e, h(p, j), k)), Object.keys(h(U, N)).length) {
                b(U, j, k);
                const st = ((c = K[0].match(/\//)) == null ? void 0 : c.length) ?? 0;
                (l[st] || (l[st] = [])).push(U);
              }
              continue;
            }
          }
          (se === true || se.test(f)) && (k[he] = f, u ? (r.push(...C(this, V, ne).call(this, U, e, k, h(p, j))), h(U, N)["*"] && r.push(...C(this, V, ne).call(this, h(U, N)["*"], e, k, h(p, j)))) : (b(U, j, k), m.push(U)));
        }
      }
      n = m.concat(l.shift() ?? []);
    }
    return r.length > 1 && r.sort((o, d) => o.score - d.score), [r.map(({ handler: o, params: d }) => [o, d])];
  }
}, te = /* @__PURE__ */ new WeakMap(), N = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), we = /* @__PURE__ */ new WeakMap(), j = /* @__PURE__ */ new WeakMap(), V = /* @__PURE__ */ new WeakSet(), ne = /* @__PURE__ */ __name2(function(e, t, r, i) {
  const n = [];
  for (let a = 0, l = h(e, te).length; a < l; a++) {
    const c = h(e, te)[a], o = c[t] || c[R], d = {};
    if (o !== void 0 && (o.params = /* @__PURE__ */ Object.create(null), n.push(o), r !== Ce || i && i !== Ce)) for (let f = 0, u = o.possibleKeys.length; f < u; f++) {
      const m = o.possibleKeys[f], g = d[o.score];
      o.params[m] = i != null && i[m] && !g ? i[m] : r[m] ?? (i == null ? void 0 : i[m]), d[o.score] = true;
    }
  }
  return n;
}, "ne"), er);
var de;
var tr;
var Ds = (tr = class {
  static {
    __name(this, "tr");
  }
  static {
    __name2(this, "tr");
  }
  constructor() {
    x(this, "name", "TrieRouter");
    E(this, de);
    b(this, de, new Rr());
  }
  add(e, t, r) {
    const i = pr(t);
    if (i) {
      for (let n = 0, a = i.length; n < a; n++) h(this, de).insert(e, i[n], r);
      return;
    }
    h(this, de).insert(e, t, r);
  }
  match(e, t) {
    return h(this, de).search(e, t);
  }
}, de = /* @__PURE__ */ new WeakMap(), tr);
var Pr = class extends Ar {
  static {
    __name(this, "Pr");
  }
  static {
    __name2(this, "Pr");
  }
  constructor(e = {}) {
    super(e), this.router = e.router ?? new Ns({ routers: [new Ms(), new Ds()] });
  }
};
var Ls = /* @__PURE__ */ __name2((e) => {
  const r = { ...{ origin: "*", allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"], allowHeaders: [], exposeHeaders: [] }, ...e }, i = /* @__PURE__ */ ((a) => typeof a == "string" ? a === "*" ? () => a : (l) => a === l ? l : null : typeof a == "function" ? a : (l) => a.includes(l) ? l : null)(r.origin), n = ((a) => typeof a == "function" ? a : Array.isArray(a) ? () => a : () => [])(r.allowMethods);
  return async function(l, c) {
    var f;
    function o(u, m) {
      l.res.headers.set(u, m);
    }
    __name(o, "o");
    __name2(o, "o");
    const d = await i(l.req.header("origin") || "", l);
    if (d && o("Access-Control-Allow-Origin", d), r.origin !== "*") {
      const u = l.req.header("Vary");
      u ? o("Vary", u) : o("Vary", "Origin");
    }
    if (r.credentials && o("Access-Control-Allow-Credentials", "true"), (f = r.exposeHeaders) != null && f.length && o("Access-Control-Expose-Headers", r.exposeHeaders.join(",")), l.req.method === "OPTIONS") {
      r.maxAge != null && o("Access-Control-Max-Age", r.maxAge.toString());
      const u = await n(l.req.header("origin") || "", l);
      u.length && o("Access-Control-Allow-Methods", u.join(","));
      let m = r.allowHeaders;
      if (!(m != null && m.length)) {
        const g = l.req.header("Access-Control-Request-Headers");
        g && (m = g.split(/\s*,\s*/));
      }
      return m != null && m.length && (o("Access-Control-Allow-Headers", m.join(",")), l.res.headers.append("Vary", "Access-Control-Request-Headers")), l.res.headers.delete("Content-Length"), l.res.headers.delete("Content-Type"), new Response(null, { headers: l.res.headers, status: 204, statusText: "No Content" });
    }
    await c();
  };
}, "Ls");
var $s = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i;
var _t = /* @__PURE__ */ __name2((e, t = Is) => {
  const r = /\.([a-zA-Z0-9]+?)$/, i = e.match(r);
  if (!i) return;
  let n = t[i[1]];
  return n && n.startsWith("text") && (n += "; charset=utf-8"), n;
}, "_t");
var _s = { aac: "audio/aac", avi: "video/x-msvideo", avif: "image/avif", av1: "video/av1", bin: "application/octet-stream", bmp: "image/bmp", css: "text/css", csv: "text/csv", eot: "application/vnd.ms-fontobject", epub: "application/epub+zip", gif: "image/gif", gz: "application/gzip", htm: "text/html", html: "text/html", ico: "image/x-icon", ics: "text/calendar", jpeg: "image/jpeg", jpg: "image/jpeg", js: "text/javascript", json: "application/json", jsonld: "application/ld+json", map: "application/json", mid: "audio/x-midi", midi: "audio/x-midi", mjs: "text/javascript", mp3: "audio/mpeg", mp4: "video/mp4", mpeg: "video/mpeg", oga: "audio/ogg", ogv: "video/ogg", ogx: "application/ogg", opus: "audio/opus", otf: "font/otf", pdf: "application/pdf", png: "image/png", rtf: "application/rtf", svg: "image/svg+xml", tif: "image/tiff", tiff: "image/tiff", ts: "video/mp2t", ttf: "font/ttf", txt: "text/plain", wasm: "application/wasm", webm: "video/webm", weba: "audio/webm", webmanifest: "application/manifest+json", webp: "image/webp", woff: "font/woff", woff2: "font/woff2", xhtml: "application/xhtml+xml", xml: "application/xml", zip: "application/zip", "3gp": "video/3gpp", "3g2": "video/3gpp2", gltf: "model/gltf+json", glb: "model/gltf-binary" };
var Is = _s;
var Hs = /* @__PURE__ */ __name2((...e) => {
  let t = e.filter((n) => n !== "").join("/");
  t = t.replace(new RegExp("(?<=\\/)\\/+", "g"), "");
  const r = t.split("/"), i = [];
  for (const n of r) n === ".." && i.length > 0 && i.at(-1) !== ".." ? i.pop() : n !== "." && i.push(n);
  return i.join("/") || ".";
}, "Hs");
var jr = { br: ".br", zstd: ".zst", gzip: ".gz" };
var Fs = Object.keys(jr);
var qs = "index.html";
var Us = /* @__PURE__ */ __name2((e) => {
  const t = e.root ?? "./", r = e.path, i = e.join ?? Hs;
  return async (n, a) => {
    var f, u, m, g;
    if (n.finalized) return a();
    let l;
    if (e.path) l = e.path;
    else try {
      if (l = decodeURIComponent(n.req.path), /(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(l)) throw new Error();
    } catch {
      return await ((f = e.onNotFound) == null ? void 0 : f.call(e, n.req.path, n)), a();
    }
    let c = i(t, !r && e.rewriteRequestPath ? e.rewriteRequestPath(l) : l);
    e.isDir && await e.isDir(c) && (c = i(c, qs));
    const o = e.getContent;
    let d = await o(c, n);
    if (d instanceof Response) return n.newResponse(d.body, d);
    if (d) {
      const y = e.mimes && _t(c, e.mimes) || _t(c);
      if (n.header("Content-Type", y || "application/octet-stream"), e.precompressed && (!y || $s.test(y))) {
        const p = new Set((u = n.req.header("Accept-Encoding")) == null ? void 0 : u.split(",").map((v) => v.trim()));
        for (const v of Fs) {
          if (!p.has(v)) continue;
          const w = await o(c + jr[v], n);
          if (w) {
            d = w, n.header("Content-Encoding", v), n.header("Vary", "Accept-Encoding", { append: true });
            break;
          }
        }
      }
      return await ((m = e.onFound) == null ? void 0 : m.call(e, c, n)), n.body(d);
    }
    await ((g = e.onNotFound) == null ? void 0 : g.call(e, c, n)), await a();
  };
}, "Us");
var Bs = /* @__PURE__ */ __name2(async (e, t) => {
  let r;
  t && t.manifest ? typeof t.manifest == "string" ? r = JSON.parse(t.manifest) : r = t.manifest : typeof __STATIC_CONTENT_MANIFEST == "string" ? r = JSON.parse(__STATIC_CONTENT_MANIFEST) : r = __STATIC_CONTENT_MANIFEST;
  let i;
  t && t.namespace ? i = t.namespace : i = __STATIC_CONTENT;
  const n = r[e] || e;
  if (!n) return null;
  const a = await i.get(n, { type: "stream" });
  return a || null;
}, "Bs");
var Ws = /* @__PURE__ */ __name2((e) => async function(r, i) {
  return Us({ ...e, getContent: /* @__PURE__ */ __name2(async (a) => Bs(a, { manifest: e.manifest, namespace: e.namespace ? e.namespace : r.env ? r.env.__STATIC_CONTENT : void 0 }), "getContent") })(r, i);
}, "Ws");
var Or = /* @__PURE__ */ __name2((e) => Ws(e), "Or");
var je = "_hp";
var Js = { Change: "Input", DoubleClick: "DblClick" };
var zs = { svg: "2000/svg", math: "1998/Math/MathML" };
var Oe = [];
var vt = /* @__PURE__ */ new WeakMap();
var Ae = void 0;
var Vs = /* @__PURE__ */ __name2(() => Ae, "Vs");
var B = /* @__PURE__ */ __name2((e) => "t" in e, "B");
var ot = { onClick: ["click", false] };
var It = /* @__PURE__ */ __name2((e) => {
  if (!e.startsWith("on")) return;
  if (ot[e]) return ot[e];
  const t = e.match(/^on([A-Z][a-zA-Z]+?(?:PointerCapture)?)(Capture)?$/);
  if (t) {
    const [, r, i] = t;
    return ot[e] = [(Js[r] || r).toLowerCase(), !!i];
  }
}, "It");
var Ht = /* @__PURE__ */ __name2((e, t) => Ae && e instanceof SVGElement && /[A-Z]/.test(t) && (t in e.style || t.match(/^(?:o|pai|str|u|ve)/)) ? t.replace(/([A-Z])/g, "-$1").toLowerCase() : t, "Ht");
var Gs = /* @__PURE__ */ __name2((e, t, r) => {
  var i;
  t || (t = {});
  for (let n in t) {
    const a = t[n];
    if (n !== "children" && (!r || r[n] !== a)) {
      n = Qe(n);
      const l = It(n);
      if (l) {
        if ((r == null ? void 0 : r[n]) !== a && (r && e.removeEventListener(l[0], r[n], l[1]), a != null)) {
          if (typeof a != "function") throw new Error(`Event handler for "${n}" is not a function`);
          e.addEventListener(l[0], a, l[1]);
        }
      } else if (n === "dangerouslySetInnerHTML" && a) e.innerHTML = a.__html;
      else if (n === "ref") {
        let c;
        typeof a == "function" ? c = a(e) || (() => a(null)) : a && "current" in a && (a.current = e, c = /* @__PURE__ */ __name2(() => a.current = null, "c")), vt.set(e, c);
      } else if (n === "style") {
        const c = e.style;
        typeof a == "string" ? c.cssText = a : (c.cssText = "", a != null && hr(a, c.setProperty.bind(c)));
      } else {
        if (n === "value") {
          const o = e.nodeName;
          if (o === "INPUT" || o === "TEXTAREA" || o === "SELECT") {
            if (e.value = a == null || a === false ? null : a, o === "TEXTAREA") {
              e.textContent = a;
              continue;
            } else if (o === "SELECT") {
              e.selectedIndex === -1 && (e.selectedIndex = 0);
              continue;
            }
          }
        } else (n === "checked" && e.nodeName === "INPUT" || n === "selected" && e.nodeName === "OPTION") && (e[n] = a);
        const c = Ht(e, n);
        a == null || a === false ? e.removeAttribute(c) : a === true ? e.setAttribute(c, "") : typeof a == "string" || typeof a == "number" ? e.setAttribute(c, a) : e.setAttribute(c, a.toString());
      }
    }
  }
  if (r) for (let n in r) {
    const a = r[n];
    if (n !== "children" && !(n in t)) {
      n = Qe(n);
      const l = It(n);
      l ? e.removeEventListener(l[0], a, l[1]) : n === "ref" ? (i = vt.get(e)) == null || i() : e.removeAttribute(Ht(e, n));
    }
  }
}, "Gs");
var Ks = /* @__PURE__ */ __name2((e, t) => {
  t[T][0] = 0, Oe.push([e, t]);
  const r = t.tag[bt] || t.tag, i = r.defaultProps ? { ...r.defaultProps, ...t.props } : t.props;
  try {
    return [r.call(null, i)];
  } finally {
    Oe.pop();
  }
}, "Ks");
var Mr = /* @__PURE__ */ __name2((e, t, r, i, n) => {
  var a, l;
  (a = e.vR) != null && a.length && (i.push(...e.vR), delete e.vR), typeof e.tag == "function" && ((l = e[T][1][$r]) == null || l.forEach((c) => n.push(c))), e.vC.forEach((c) => {
    var o;
    if (B(c)) r.push(c);
    else if (typeof c.tag == "function" || c.tag === "") {
      c.c = t;
      const d = r.length;
      if (Mr(c, t, r, i, n), c.s) {
        for (let f = d; f < r.length; f++) r[f].s = true;
        c.s = false;
      }
    } else r.push(c), (o = c.vR) != null && o.length && (i.push(...c.vR), delete c.vR);
  });
}, "Mr");
var Ys = /* @__PURE__ */ __name2((e) => {
  for (; ; e = e.tag === je || !e.vC || !e.pP ? e.nN : e.vC[0]) {
    if (!e) return null;
    if (e.tag !== je && e.e) return e.e;
  }
}, "Ys");
var Nr = /* @__PURE__ */ __name2((e) => {
  var t, r, i, n, a, l;
  B(e) || ((r = (t = e[T]) == null ? void 0 : t[1][$r]) == null || r.forEach((c) => {
    var o;
    return (o = c[2]) == null ? void 0 : o.call(c);
  }), (i = vt.get(e.e)) == null || i(), e.p === 2 && ((n = e.vC) == null || n.forEach((c) => c.p = 2)), (a = e.vC) == null || a.forEach(Nr)), e.p || ((l = e.e) == null || l.remove(), delete e.e), typeof e.tag == "function" && (Se.delete(e), Ye.delete(e), delete e[T][3], e.a = true);
}, "Nr");
var Dr = /* @__PURE__ */ __name2((e, t, r) => {
  e.c = t, Lr(e, t, r);
}, "Dr");
var Ft = /* @__PURE__ */ __name2((e, t) => {
  if (t) {
    for (let r = 0, i = e.length; r < i; r++) if (e[r] === t) return r;
  }
}, "Ft");
var qt = Symbol();
var Lr = /* @__PURE__ */ __name2((e, t, r) => {
  var d;
  const i = [], n = [], a = [];
  Mr(e, t, i, n, a), n.forEach(Nr);
  const l = r ? void 0 : t.childNodes;
  let c, o = null;
  if (r) c = -1;
  else if (!l.length) c = 0;
  else {
    const f = Ft(l, Ys(e.nN));
    f !== void 0 ? (o = l[f], c = f) : c = Ft(l, (d = i.find((u) => u.tag !== je && u.e)) == null ? void 0 : d.e) ?? -1, c === -1 && (r = true);
  }
  for (let f = 0, u = i.length; f < u; f++, c++) {
    const m = i[f];
    let g;
    if (m.s && m.e) g = m.e, m.s = false;
    else {
      const y = r || !m.e;
      B(m) ? (m.e && m.d && (m.e.textContent = m.t), m.d = false, g = m.e || (m.e = document.createTextNode(m.t))) : (g = m.e || (m.e = m.n ? document.createElementNS(m.n, m.tag) : document.createElement(m.tag)), Gs(g, m.props, m.pP), Lr(m, g, y));
    }
    m.tag === je ? c-- : r ? g.parentNode || t.appendChild(g) : l[c] !== g && l[c - 1] !== g && (l[c + 1] === g ? t.appendChild(l[c]) : t.insertBefore(g, o || l[c] || null));
  }
  if (e.pP && delete e.pP, a.length) {
    const f = [], u = [];
    a.forEach(([, m, , g, y]) => {
      m && f.push(m), g && u.push(g), y == null || y();
    }), f.forEach((m) => m()), u.length && requestAnimationFrame(() => {
      u.forEach((m) => m());
    });
  }
}, "Lr");
var Xs = /* @__PURE__ */ __name2((e, t) => !!(e && e.length === t.length && e.every((r, i) => r[1] === t[i][1])), "Xs");
var Ye = /* @__PURE__ */ new WeakMap();
var yt = /* @__PURE__ */ __name2((e, t, r) => {
  var a, l, c, o, d, f;
  const i = !r && t.pC;
  r && (t.pC || (t.pC = t.vC));
  let n;
  try {
    r || (r = typeof t.tag == "function" ? Ks(e, t) : Ie(t.props.children)), ((a = r[0]) == null ? void 0 : a.tag) === "" && r[0][mt] && (n = r[0][mt], e[5].push([e, n, t]));
    const u = i ? [...t.pC] : t.vC ? [...t.vC] : void 0, m = [];
    let g;
    for (let y = 0; y < r.length; y++) {
      Array.isArray(r[y]) && r.splice(y, 1, ...r[y].flat());
      let p = Zs(r[y]);
      if (p) {
        typeof p.tag == "function" && !p.tag[ar] && (Ee.length > 0 && (p[T][2] = Ee.map((w) => [w, w.values.at(-1)])), (l = e[5]) != null && l.length && (p[T][3] = e[5].at(-1)));
        let v;
        if (u && u.length) {
          const w = u.findIndex(B(p) ? (A) => B(A) : p.key !== void 0 ? (A) => A.key === p.key && A.tag === p.tag : (A) => A.tag === p.tag);
          w !== -1 && (v = u[w], u.splice(w, 1));
        }
        if (v) if (B(p)) v.t !== p.t && (v.t = p.t, v.d = true), p = v;
        else {
          const w = v.pP = v.props;
          if (v.props = p.props, v.f || (v.f = p.f || t.f), typeof p.tag == "function") {
            const A = v[T][2];
            v[T][2] = p[T][2] || [], v[T][3] = p[T][3], !v.f && ((v.o || v) === p.o || (o = (c = v.tag)[zr]) != null && o.call(c, w, v.props)) && Xs(A, v[T][2]) && (v.s = true);
          }
          p = v;
        }
        else if (!B(p) && Ae) {
          const w = ke(Ae);
          w && (p.n = w);
        }
        if (!B(p) && !p.s && (yt(e, p), delete p.f), m.push(p), g && !g.s && !p.s) for (let w = g; w && !B(w); w = (d = w.vC) == null ? void 0 : d.at(-1)) w.nN = p;
        g = p;
      }
    }
    t.vR = i ? [...t.vC, ...u || []] : u || [], t.vC = m, i && delete t.pC;
  } catch (u) {
    if (t.f = true, u === qt) {
      if (n) return;
      throw u;
    }
    const [m, g, y] = ((f = t[T]) == null ? void 0 : f[3]) || [];
    if (g) {
      const p = /* @__PURE__ */ __name2(() => Xe([0, false, e[2]], y), "p"), v = Ye.get(y) || [];
      v.push(p), Ye.set(y, v);
      const w = g(u, () => {
        const A = Ye.get(y);
        if (A) {
          const S = A.indexOf(p);
          if (S !== -1) return A.splice(S, 1), p();
        }
      });
      if (w) {
        if (e[0] === 1) e[1] = true;
        else if (yt(e, y, [w]), (g.length === 1 || e !== m) && y.c) {
          Dr(y, y.c, false);
          return;
        }
        throw qt;
      }
    }
    throw u;
  } finally {
    n && e[5].pop();
  }
}, "yt");
var Zs = /* @__PURE__ */ __name2((e) => {
  if (!(e == null || typeof e == "boolean")) {
    if (typeof e == "string" || typeof e == "number") return { t: e.toString(), d: true };
    if ("vR" in e && (e = { tag: e.tag, props: e.props, key: e.key, f: e.f, type: e.tag, ref: e.props.ref, o: e.o || e }), typeof e.tag == "function") e[T] = [0, []];
    else {
      const t = zs[e.tag];
      t && (Ae || (Ae = cr("")), e.props.children = [{ tag: Ae, props: { value: e.n = `http://www.w3.org/${t}`, children: e.props.children } }]);
    }
    return e;
  }
}, "Zs");
var Ut = /* @__PURE__ */ __name2((e, t) => {
  var r, i;
  (r = t[T][2]) == null || r.forEach(([n, a]) => {
    n.values.push(a);
  });
  try {
    yt(e, t, void 0);
  } catch {
    return;
  }
  if (t.a) {
    delete t.a;
    return;
  }
  (i = t[T][2]) == null || i.forEach(([n]) => {
    n.values.pop();
  }), (e[0] !== 1 || !e[1]) && Dr(t, t.c, false);
}, "Ut");
var Se = /* @__PURE__ */ new WeakMap();
var Bt = [];
var Xe = /* @__PURE__ */ __name2(async (e, t) => {
  e[5] || (e[5] = []);
  const r = Se.get(t);
  r && r[0](void 0);
  let i;
  const n = new Promise((a) => i = a);
  if (Se.set(t, [i, () => {
    e[2] ? e[2](e, t, (a) => {
      Ut(a, t);
    }).then(() => i(t)) : (Ut(e, t), i(t));
  }]), Bt.length) Bt.at(-1).add(t);
  else {
    await Promise.resolve();
    const a = Se.get(t);
    a && (Se.delete(t), a[1]());
  }
  return n;
}, "Xe");
var Qs = /* @__PURE__ */ __name2((e, t, r) => ({ tag: je, props: { children: e }, key: r, e: t, p: 1 }), "Qs");
var dt = 0;
var $r = 1;
var ht = 2;
var ft = 3;
var ut = /* @__PURE__ */ new WeakMap();
var _r = /* @__PURE__ */ __name2((e, t) => !e || !t || e.length !== t.length || t.some((r, i) => r !== e[i]), "_r");
var ei = void 0;
var Wt = [];
var ti = /* @__PURE__ */ __name2((e) => {
  var l;
  const t = /* @__PURE__ */ __name2(() => typeof e == "function" ? e() : e, "t"), r = Oe.at(-1);
  if (!r) return [t(), () => {
  }];
  const [, i] = r, n = (l = i[T][1])[dt] || (l[dt] = []), a = i[T][0]++;
  return n[a] || (n[a] = [t(), (c) => {
    const o = ei, d = n[a];
    if (typeof c == "function" && (c = c(d[0])), !Object.is(c, d[0])) if (d[0] = c, Wt.length) {
      const [f, u] = Wt.at(-1);
      Promise.all([f === 3 ? i : Xe([f, false, o], i), u]).then(([m]) => {
        if (!m || !(f === 2 || f === 3)) return;
        const g = m.vC;
        requestAnimationFrame(() => {
          setTimeout(() => {
            g === m.vC && Xe([f === 3 ? 1 : 0, false, o], m);
          });
        });
      });
    } else Xe([0, false, o], i);
  }]);
}, "ti");
var Ct = /* @__PURE__ */ __name2((e, t) => {
  var c;
  const r = Oe.at(-1);
  if (!r) return e;
  const [, i] = r, n = (c = i[T][1])[ht] || (c[ht] = []), a = i[T][0]++, l = n[a];
  return _r(l == null ? void 0 : l[1], t) ? n[a] = [e, t] : e = n[a][0], e;
}, "Ct");
var ri = /* @__PURE__ */ __name2((e) => {
  const t = ut.get(e);
  if (t) {
    if (t.length === 2) throw t[1];
    return t[0];
  }
  throw e.then((r) => ut.set(e, [r]), (r) => ut.set(e, [void 0, r])), e;
}, "ri");
var si = /* @__PURE__ */ __name2((e, t) => {
  var c;
  const r = Oe.at(-1);
  if (!r) return e();
  const [, i] = r, n = (c = i[T][1])[ft] || (c[ft] = []), a = i[T][0]++, l = n[a];
  return _r(l == null ? void 0 : l[1], t) && (n[a] = [e(), t]), n[a][0];
}, "si");
var ii = cr({ pending: false, data: null, method: null, action: null });
var Jt = /* @__PURE__ */ new Set();
var ni = /* @__PURE__ */ __name2((e) => {
  Jt.add(e), e.finally(() => Jt.delete(e));
}, "ni");
var St = /* @__PURE__ */ __name2((e, t) => si(() => (r) => {
  let i;
  e && (typeof e == "function" ? i = e(r) || (() => {
    e(null);
  }) : e && "current" in e && (e.current = r, i = /* @__PURE__ */ __name2(() => {
    e.current = null;
  }, "i")));
  const n = t(r);
  return () => {
    n == null || n(), i == null || i();
  };
}, [e]), "St");
var ue = /* @__PURE__ */ Object.create(null);
var Be = /* @__PURE__ */ Object.create(null);
var qe = /* @__PURE__ */ __name2((e, t, r, i, n) => {
  if (t != null && t.itemProp) return { tag: e, props: t, type: e, ref: t.ref };
  const a = document.head;
  let { onLoad: l, onError: c, precedence: o, blocking: d, ...f } = t, u = null, m = false;
  const g = We[e];
  let y;
  if (g.length > 0) {
    const A = a.querySelectorAll(e);
    e: for (const S of A) for (const k of We[e]) if (S.getAttribute(k) === t[k]) {
      u = S;
      break e;
    }
    if (!u) {
      const S = g.reduce((k, M) => t[M] === void 0 ? k : `${k}-${M}-${t[M]}`, e);
      m = !Be[S], u = Be[S] || (Be[S] = (() => {
        const k = document.createElement(e);
        for (const M of g) t[M] !== void 0 && k.setAttribute(M, t[M]), t.rel && k.setAttribute("rel", t.rel);
        return k;
      })());
    }
  } else y = a.querySelectorAll(e);
  o = i ? o ?? "" : void 0, i && (f[Je] = o);
  const p = Ct((A) => {
    if (g.length > 0) {
      let S = false;
      for (const k of a.querySelectorAll(e)) {
        if (S && k.getAttribute(Je) !== o) {
          a.insertBefore(A, k);
          return;
        }
        k.getAttribute(Je) === o && (S = true);
      }
      a.appendChild(A);
    } else if (y) {
      let S = false;
      for (const k of y) if (k === A) {
        S = true;
        break;
      }
      S || a.insertBefore(A, a.contains(y[0]) ? y[0] : a.querySelector(e)), y = void 0;
    }
  }, [o]), v = St(t.ref, (A) => {
    var M;
    const S = g[0];
    if (r === 2 && (A.innerHTML = ""), (m || y) && p(A), !c && !l) return;
    let k = ue[M = A.getAttribute(S)] || (ue[M] = new Promise((he, se) => {
      A.addEventListener("load", he), A.addEventListener("error", se);
    }));
    l && (k = k.then(l)), c && (k = k.catch(c)), k.catch(() => {
    });
  });
  if (n && d === "render") {
    const A = We[e][0];
    if (t[A]) {
      const S = t[A], k = ue[S] || (ue[S] = new Promise((M, he) => {
        p(u), u.addEventListener("load", M), u.addEventListener("error", he);
      }));
      ri(k);
    }
  }
  const w = { tag: e, type: e, props: { ...f, ref: v }, ref: v };
  return w.p = r, u && (w.e = u), Qs(w, a);
}, "qe");
var ai = /* @__PURE__ */ __name2((e) => {
  const t = Vs(), r = t && ke(t);
  return r != null && r.endsWith("svg") ? { tag: "title", props: e, type: "title", ref: e.ref } : qe("title", e, void 0, false, false);
}, "ai");
var li = /* @__PURE__ */ __name2((e) => !e || ["src", "async"].some((t) => !e[t]) ? { tag: "script", props: e, type: "script", ref: e.ref } : qe("script", e, 1, false, true), "li");
var ci = /* @__PURE__ */ __name2((e) => !e || !["href", "precedence"].every((t) => t in e) ? { tag: "style", props: e, type: "style", ref: e.ref } : (e["data-href"] = e.href, delete e.href, qe("style", e, 2, true, true)), "ci");
var oi = /* @__PURE__ */ __name2((e) => !e || ["onLoad", "onError"].some((t) => t in e) || e.rel === "stylesheet" && (!("precedence" in e) || "disabled" in e) ? { tag: "link", props: e, type: "link", ref: e.ref } : qe("link", e, 1, "precedence" in e, true), "oi");
var di = /* @__PURE__ */ __name2((e) => qe("meta", e, void 0, false, false), "di");
var Ir = Symbol();
var hi = /* @__PURE__ */ __name2((e) => {
  const { action: t, ...r } = e;
  typeof t != "function" && (r.action = t);
  const [i, n] = ti([null, false]), a = Ct(async (d) => {
    const f = d.isTrusted ? t : d.detail[Ir];
    if (typeof f != "function") return;
    d.preventDefault();
    const u = new FormData(d.target);
    n([u, true]);
    const m = f(u);
    m instanceof Promise && (ni(m), await m), n([null, true]);
  }, []), l = St(e.ref, (d) => (d.addEventListener("submit", a), () => {
    d.removeEventListener("submit", a);
  })), [c, o] = i;
  return i[1] = false, { tag: ii, props: { value: { pending: c !== null, data: c, method: c ? "post" : null, action: c ? t : null }, children: { tag: "form", props: { ...r, ref: l }, type: "form", ref: l } }, f: o };
}, "hi");
var Hr = /* @__PURE__ */ __name2((e, { formAction: t, ...r }) => {
  if (typeof t == "function") {
    const i = Ct((n) => {
      n.preventDefault(), n.currentTarget.form.dispatchEvent(new CustomEvent("submit", { detail: { [Ir]: t } }));
    }, []);
    r.ref = St(r.ref, (n) => (n.addEventListener("click", i), () => {
      n.removeEventListener("click", i);
    }));
  }
  return { tag: e, props: r, type: e, ref: r.ref };
}, "Hr");
var fi = /* @__PURE__ */ __name2((e) => Hr("input", e), "fi");
var ui = /* @__PURE__ */ __name2((e) => Hr("button", e), "ui");
Object.assign(pt, { title: ai, script: li, style: ci, link: oi, meta: di, form: hi, input: fi, button: ui });
wt(null);
new TextEncoder();
var mi = wt(null);
var pi = /* @__PURE__ */ __name2((e, t, r, i) => (n, a) => {
  const l = "<!DOCTYPE html>", c = r ? Mt((d) => r(d, e), { Layout: t, ...a }, n) : n, o = Jr`${$(l)}${Mt(mi.Provider, { value: e }, c)}`;
  return e.html(o);
}, "pi");
var gi = /* @__PURE__ */ __name2((e, t) => function(i, n) {
  const a = i.getLayout() ?? q;
  return e && i.setLayout((l) => e({ ...l, Layout: a }, i)), i.setRenderer(pi(i, a, e)), n();
}, "gi");
var xi = gi(({ children: e, title: t }) => s("html", { lang: "en", children: [s("head", { children: [s("meta", { charset: "UTF-8" }), s("meta", { name: "viewport", content: "width=device-width, initial-scale=1.0" }), s("meta", { name: "description", content: "Master futures trading with institutional strategies - Auction Market Theory, Smart Money Concepts, and CME Fair Price Redelivery" }), s("title", { children: t || "Futures Trading Academy - Professional Trading Education" }), s("script", { src: "https://cdn.tailwindcss.com" }), s("link", { href: "https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css", rel: "stylesheet" }), s("link", { href: "/static/styles.css", rel: "stylesheet" })] }), s("body", { children: [s("nav", { class: "navbar py-4", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center", children: [s("a", { href: "/", class: "text-2xl font-bold gradient-text", children: [s("i", { class: "fas fa-chart-line mr-2" }), "Trading Academy"] }), s("div", { class: "hidden md:flex space-x-6", children: [s("a", { href: "/", class: "text-gray-300 hover:text-white transition", children: "Home" }), s("a", { href: "/curriculum", class: "text-gray-300 hover:text-white transition", children: "Curriculum" }), s("a", { href: "/pricing", class: "text-gray-300 hover:text-white transition", children: "Pricing" }), s("a", { href: "/about", class: "text-gray-300 hover:text-white transition", children: "About" }), s("a", { href: "/faq", class: "text-gray-300 hover:text-white transition", children: "FAQ" }), s("a", { href: "/downloads", class: "text-gray-300 hover:text-white transition", children: [s("i", { class: "fas fa-download mr-1" }), "Docs"] })] }), s("a", { href: "/waitlist", class: "btn btn-primary", children: [s("i", { class: "fas fa-user-plus mr-2" }), "Join Waitlist"] })] }) }), s("main", { children: e }), s("footer", { class: "bg-slate-950 py-12", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "grid md:grid-cols-4 gap-8 mb-8", children: [s("div", { children: [s("h3", { class: "text-xl font-bold gradient-text mb-4", children: "Trading Academy" }), s("p", { class: "text-gray-400", children: "Professional futures trading education with institutional strategies" })] }), s("div", { children: [s("h4", { class: "font-bold mb-4", children: "Learn" }), s("ul", { class: "space-y-2 text-gray-400", children: [s("li", { children: s("a", { href: "/curriculum", class: "hover:text-white", children: "Curriculum" }) }), s("li", { children: s("a", { href: "/pricing", class: "hover:text-white", children: "Pricing" }) }), s("li", { children: s("a", { href: "/faq", class: "hover:text-white", children: "FAQ" }) }), s("li", { children: s("a", { href: "/downloads", class: "hover:text-white", children: [s("i", { class: "fas fa-download mr-1" }), "Documentation"] }) })] })] }), s("div", { children: [s("h4", { class: "font-bold mb-4", children: "Company" }), s("ul", { class: "space-y-2 text-gray-400", children: [s("li", { children: s("a", { href: "/about", class: "hover:text-white", children: "About Us" }) }), s("li", { children: s("a", { href: "/contact", class: "hover:text-white", children: "Contact" }) }), s("li", { children: s("a", { href: "/careers", class: "hover:text-white", children: "Careers" }) })] })] }), s("div", { children: [s("h4", { class: "font-bold mb-4", children: "Legal" }), s("ul", { class: "space-y-2 text-gray-400", children: [s("li", { children: s("a", { href: "/terms", class: "hover:text-white", children: "Terms of Service" }) }), s("li", { children: s("a", { href: "/privacy", class: "hover:text-white", children: "Privacy Policy" }) }), s("li", { children: s("a", { href: "/disclaimer", class: "hover:text-white", children: "Risk Disclaimer" }) })] })] })] }), s("div", { class: "border-t border-gray-800 pt-8 text-center text-gray-400", children: [s("p", { children: "\xA9 2025 Futures Trading Academy. All rights reserved." }), s("div", { class: "mt-4 flex justify-center space-x-6", children: [s("a", { href: "#", class: "hover:text-white", children: s("i", { class: "fab fa-twitter" }) }), s("a", { href: "#", class: "hover:text-white", children: s("i", { class: "fab fa-youtube" }) }), s("a", { href: "#", class: "hover:text-white", children: s("i", { class: "fab fa-discord" }) }), s("a", { href: "#", class: "hover:text-white", children: s("i", { class: "fab fa-telegram" }) })] })] })] }) })] })] }));
var O = new Pr();
O.use("/api/*", Ls());
O.use("/static/*", Or({ root: "./public" }));
O.use("/docs/*", Or({ root: "./" }));
O.use(xi);
O.get("/", (e) => e.render(s(q, { children: [s("section", { class: "hero py-20 relative", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10", children: [s("div", { class: "text-center", children: [s("div", { class: "mb-6", children: s("span", { class: "badge badge-blue text-sm", children: [s("i", { class: "fas fa-chart-line mr-2" }), "Professional Futures Trading Education"] }) }), s("h1", { class: "text-5xl md:text-7xl font-bold mb-6", children: ["Master ", s("span", { class: "gradient-text", children: "Futures Trading" }), s("br", {}), "with Institutional Strategies"] }), s("p", { class: "text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto", children: "Learn auction market theory, smart money concepts, and CME fair price strategies from professional traders. Transform from retail to institutional thinking." }), s("div", { class: "flex flex-col sm:flex-row gap-4 justify-center items-center", children: [s("a", { href: "/waitlist", class: "btn btn-primary", children: [s("i", { class: "fas fa-rocket mr-2" }), "Join Waitlist"] }), s("a", { href: "/curriculum", class: "btn btn-secondary", children: [s("i", { class: "fas fa-book-open mr-2" }), "Explore Curriculum"] })] })] }), s("div", { class: "grid grid-cols-2 md:grid-cols-4 gap-6 mt-16", children: [s("div", { class: "stat-card", children: [s("div", { class: "stat-number", children: "500+" }), s("div", { class: "text-gray-400", children: "Students Enrolled" })] }), s("div", { class: "stat-card", children: [s("div", { class: "stat-number", children: "40+" }), s("div", { class: "text-gray-400", children: "Hours of Content" })] }), s("div", { class: "stat-card", children: [s("div", { class: "stat-number", children: "98%" }), s("div", { class: "text-gray-400", children: "Success Rate" })] }), s("div", { class: "stat-card", children: [s("div", { class: "stat-number", children: "24/7" }), s("div", { class: "text-gray-400", children: "Community Support" })] })] })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "text-center mb-16", children: [s("h2", { class: "text-4xl md:text-5xl font-bold mb-4", children: ["Why Learn ", s("span", { class: "gradient-text", children: "With Us?" })] }), s("p", { class: "text-xl text-gray-400 max-w-2xl mx-auto", children: "Professional trading education designed to give you the edge in futures markets" })] }), s("div", { class: "grid md:grid-cols-3 gap-8", children: [s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-graduation-cap" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Institutional Knowledge" }), s("p", { class: "text-gray-400", children: "Learn how market makers, banks, and professional traders actually think and operate. Understand order flow, liquidity dynamics, and institutional positioning." })] }), s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-chart-bar" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Proven Methodologies" }), s("p", { class: "text-gray-400", children: "Master auction market theory, volume profile analysis, and smart money concepts. Time-tested strategies used by successful professional traders." })] }), s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-users" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Live Trading & Support" }), s("p", { class: "text-gray-400", children: "Join live trading sessions, get real-time market analysis, and interact with experienced mentors. Access our 24/7 trading community." })] }), s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-laptop-code" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Comprehensive Platform" }), s("p", { class: "text-gray-400", children: "Access video lectures, interactive exercises, trading simulations, and real-time market analysis tools. Learn at your own pace." })] }), s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-briefcase" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Career Opportunities" }), s("p", { class: "text-gray-400", children: "Get connected with proprietary trading firms and institutional opportunities. Our job board features exclusive positions for certified students." })] }), s("div", { class: "card text-center", children: [s("div", { class: "feature-icon mx-auto", children: s("i", { class: "fas fa-trophy" }) }), s("h3", { class: "text-2xl font-bold mb-3", children: "Proven Results" }), s("p", { class: "text-gray-400", children: "Join hundreds of successful traders who have transformed their trading with our methodology. Track record of student success and profitability." })] })] })] }) }), s("section", { class: "py-20 bg-slate-800", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "text-center mb-16", children: [s("h2", { class: "text-4xl md:text-5xl font-bold mb-4", children: ["Complete ", s("span", { class: "gradient-text", children: "Trading Curriculum" })] }), s("p", { class: "text-xl text-gray-400 max-w-2xl mx-auto", children: "Four comprehensive campuses covering everything from fundamentals to advanced institutional strategies" })] }), s("div", { class: "grid md:grid-cols-2 gap-8", children: [s("div", { class: "card", children: [s("div", { class: "flex items-start mb-4", children: [s("div", { class: "feature-icon", children: s("i", { class: "fas fa-gavel" }) }), s("div", { class: "ml-4", children: [s("span", { class: "badge badge-blue mb-2", children: "Campus 1" }), s("h3", { class: "text-2xl font-bold", children: "Auction Market Theory" })] })] }), s("p", { class: "text-gray-400 mb-4", children: "Master the foundation of how markets actually work through auction dynamics, market profile, and volume profile analysis." }), s("ul", { class: "space-y-2 text-gray-300", children: [s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Market structure fundamentals"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " TPO and value area analysis"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Volume profile construction"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Advanced volume strategies"] })] })] }), s("div", { class: "card", children: [s("div", { class: "flex items-start mb-4", children: [s("div", { class: "feature-icon", children: s("i", { class: "fas fa-brain" }) }), s("div", { class: "ml-4", children: [s("span", { class: "badge badge-gold mb-2", children: "Campus 2" }), s("h3", { class: "text-2xl font-bold", children: "Smart Money Concepts" })] })] }), s("p", { class: "text-gray-400 mb-4", children: "Learn to identify and trade with institutional money flow, order blocks, and liquidity dynamics used by market makers." }), s("ul", { class: "space-y-2 text-gray-300", children: [s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Order flow & market structure"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Liquidity sweeps and runs"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Order blocks and fair value gaps"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Break of structure strategies"] })] })] }), s("div", { class: "card", children: [s("div", { class: "flex items-start mb-4", children: [s("div", { class: "feature-icon", children: s("i", { class: "fas fa-balance-scale" }) }), s("div", { class: "ml-4", children: [s("span", { class: "badge badge-green mb-2", children: "Campus 3" }), s("h3", { class: "text-2xl font-bold", children: "CME Fair Price Redelivery" })] })] }), s("p", { class: "text-gray-400 mb-4", children: "Exploit inefficiencies in overnight and gap trading using professional fair value calculations and opening range strategies." }), s("ul", { class: "space-y-2 text-gray-300", children: [s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " CME market mechanics"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Fair value calculations"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Gap trading strategies"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Opening range techniques"] })] })] }), s("div", { class: "card", children: [s("div", { class: "flex items-start mb-4", children: [s("div", { class: "feature-icon", children: s("i", { class: "fas fa-video" }) }), s("div", { class: "ml-4", children: [s("span", { class: "badge badge-blue mb-2", children: "Campus 4" }), s("h3", { class: "text-2xl font-bold", children: "Live Trading Campus" })] })] }), s("p", { class: "text-gray-400 mb-4", children: "Apply everything in real-time with live market analysis, trading sessions, and professional trader commentary." }), s("ul", { class: "space-y-2 text-gray-300", children: [s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Daily live trading sessions"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Real-time market analysis"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Trade management coaching"] }), s("li", { children: [s("i", { class: "fas fa-check text-green-500 mr-2" }), " Psychology & risk management"] })] })] })] }), s("div", { class: "text-center mt-12", children: s("a", { href: "/curriculum", class: "btn btn-primary", children: [s("i", { class: "fas fa-arrow-right mr-2" }), "View Complete Curriculum"] }) })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "text-center mb-16", children: [s("h2", { class: "text-4xl md:text-5xl font-bold mb-4", children: ["Choose Your ", s("span", { class: "gradient-text", children: "Learning Path" })] }), s("p", { class: "text-xl text-gray-400 max-w-2xl mx-auto", children: "From foundation to professional trading, select the tier that matches your goals" })] }), s("div", { class: "grid md:grid-cols-4 gap-6", children: [s("div", { class: "card text-center", children: [s("span", { class: "badge badge-blue mb-4", children: "Foundation" }), s("div", { class: "text-4xl font-bold gradient-text mb-2", children: "$97" }), s("div", { class: "text-gray-400 mb-4", children: "per month" }), s("p", { class: "text-gray-400 text-sm mb-4", children: "Perfect for beginners starting their trading journey" }), s("a", { href: "/pricing", class: "btn btn-secondary w-full", children: "Learn More" })] }), s("div", { class: "card text-center border-2 border-gold-500 relative", children: [s("div", { class: "absolute top-0 right-0 bg-yellow-500 text-slate-900 px-3 py-1 text-xs font-bold rounded-bl-lg", children: "POPULAR" }), s("span", { class: "badge badge-gold mb-4", children: "Professional" }), s("div", { class: "text-4xl font-bold gradient-text mb-2", children: "$197" }), s("div", { class: "text-gray-400 mb-4", children: "per month" }), s("p", { class: "text-gray-400 text-sm mb-4", children: "Full access with live sessions and premium signals" }), s("a", { href: "/pricing", class: "btn btn-gold w-full", children: "Learn More" })] }), s("div", { class: "card text-center", children: [s("span", { class: "badge badge-green mb-4", children: "Elite" }), s("div", { class: "text-4xl font-bold gradient-text mb-2", children: "$497" }), s("div", { class: "text-gray-400 mb-4", children: "per month" }), s("p", { class: "text-gray-400 text-sm mb-4", children: "Personal coaching and prop firm placement help" }), s("a", { href: "/pricing", class: "btn btn-secondary w-full", children: "Learn More" })] }), s("div", { class: "card text-center", children: [s("span", { class: "badge badge-gold mb-4", children: "Business" }), s("div", { class: "text-4xl font-bold gradient-text mb-2", children: "$997" }), s("div", { class: "text-gray-400 mb-4", children: "per month" }), s("p", { class: "text-gray-400 text-sm mb-4", children: "Revenue sharing and business partnerships" }), s("a", { href: "/pricing", class: "btn btn-secondary w-full", children: "Learn More" })] })] })] }) }), s("section", { class: "py-20 bg-gradient-to-br from-blue-900 to-slate-900", children: s("div", { class: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("h2", { class: "text-4xl md:text-5xl font-bold mb-6", children: "Ready to Transform Your Trading?" }), s("p", { class: "text-xl text-gray-300 mb-8", children: "Join hundreds of successful traders who have mastered institutional strategies" }), s("div", { class: "flex flex-col sm:flex-row gap-4 justify-center", children: [s("a", { href: "/waitlist", class: "btn btn-gold text-lg", children: [s("i", { class: "fas fa-rocket mr-2" }), "Join Waitlist Now"] }), s("a", { href: "/about", class: "btn btn-secondary text-lg", children: [s("i", { class: "fas fa-info-circle mr-2" }), "Learn More About Us"] })] })] }) })] })));
O.get("/curriculum", (e) => e.render(s(q, { children: [s("section", { class: "hero py-16", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Complete ", s("span", { class: "gradient-text", children: "Trading Curriculum" })] }), s("p", { class: "text-xl text-gray-300 max-w-3xl mx-auto", children: "A comprehensive, step-by-step journey from retail trader to institutional-level thinking" })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("p", { class: "text-gray-400 mb-8", children: "Detailed curriculum pages coming soon. In the meantime, view our overview on the home page." }), s("a", { href: "/", class: "btn btn-primary", children: "Back to Home" })] }) })] })));
O.get("/pricing", (e) => e.html(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing - Futures Trading Academy</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/static/styles.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar py-4">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text">Trading Academy</a>
            <div class="hidden md:flex space-x-6">
                <a href="/" class="text-gray-300 hover:text-white">Home</a>
                <a href="/curriculum" class="text-gray-300 hover:text-white">Curriculum</a>
                <a href="/pricing" class="text-white font-semibold">Pricing</a>
                <a href="/about" class="text-gray-300 hover:text-white">About</a>
            </div>
            <a href="/waitlist" class="btn btn-primary">Join Waitlist</a>
        </div>
    </nav>
    <section class="py-20 bg-slate-900 min-h-screen flex items-center justify-center">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h1 class="text-5xl font-bold mb-6">Pricing <span class="gradient-text">Coming Soon</span></h1>
            <p class="text-xl text-gray-400 mb-8">We're finalizing our pricing tiers. Join the waitlist to get notified when we launch!</p>
            <a href="/waitlist" class="btn btn-primary">Join Waitlist</a>
        </div>
    </section>
</body>
</html>`));
O.get("/waitlist", (e) => e.html(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Waitlist - Futures Trading Academy</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/static/styles.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar py-4">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text">Trading Academy</a>
            <a href="/" class="text-gray-300 hover:text-white">\u2190 Back to Home</a>
        </div>
    </nav>
    <section class="py-20 bg-slate-900">
        <div class="max-w-2xl mx-auto px-4">
            <div class="text-center mb-12">
                <h1 class="text-5xl font-bold mb-4">Join the <span class="gradient-text">Waitlist</span></h1>
                <p class="text-xl text-gray-400">Be the first to know when we launch</p>
            </div>
            <div class="card">
                <div id="success-message" class="hidden alert alert-success mb-6">
                    <i class="fas fa-check-circle mr-2"></i>
                    Thank you! You've been added to our waitlist.
                </div>
                <form id="waitlist-form" class="space-y-6">
                    <div>
                        <label class="block text-sm font-semibold mb-2">First Name *</label>
                        <input type="text" name="first_name" required placeholder="John" class="w-full" />
                    </div>
                    <div>
                        <label class="block text-sm font-semibold mb-2">Last Name *</label>
                        <input type="text" name="last_name" required placeholder="Doe" class="w-full" />
                    </div>
                    <div>
                        <label class="block text-sm font-semibold mb-2">Email Address *</label>
                        <input type="email" name="email" required placeholder="john@example.com" class="w-full" />
                    </div>
                    <div>
                        <label class="block text-sm font-semibold mb-2">Trading Experience</label>
                        <select name="experience" class="w-full">
                            <option value="">Select your level...</option>
                            <option value="beginner">Beginner (0-1 years)</option>
                            <option value="intermediate">Intermediate (1-3 years)</option>
                            <option value="advanced">Advanced (3-5 years)</option>
                            <option value="professional">Professional (5+ years)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-paper-plane mr-2"></i>
                        Join Waitlist
                    </button>
                </form>
            </div>
        </div>
    </section>
    <script>
        document.getElementById('waitlist-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());
            try {
                const response = await fetch('/api/waitlist', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                if (response.ok) {
                    document.getElementById('success-message').classList.remove('hidden');
                    document.getElementById('waitlist-form').classList.add('hidden');
                }
            } catch (error) {
                alert('Error submitting form. Please try again.');
            }
        });
    <\/script>
</body>
</html>`));
O.post("/api/waitlist", async (e) => {
  try {
    const t = await e.req.json();
    return console.log("New waitlist signup:", t), e.json({ success: true, message: "Successfully added to waitlist" });
  } catch {
    return e.json({ success: false, message: "Error processing request" }, 400);
  }
});
O.get("/about", (e) => e.render(s(q, { children: [s("section", { class: "hero py-16", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["About ", s("span", { class: "gradient-text", children: "Trading Academy" })] }), s("p", { class: "text-xl text-gray-300 max-w-3xl mx-auto", children: "Bridging the gap between retail traders and institutional knowledge" })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: s("div", { class: "max-w-4xl mx-auto", children: [s("div", { class: "card mb-12", children: [s("h2", { class: "text-3xl font-bold mb-6 text-center", children: "Our Mission" }), s("p", { class: "text-lg text-gray-300 text-center", children: "To democratize institutional-grade trading education and empower retail traders with the same methodologies, strategies, and mindset used by professional traders at banks, hedge funds, and proprietary trading firms." })] }), s("div", { class: "grid md:grid-cols-3 gap-8 mb-12", children: [s("div", { class: "card text-center", children: [s("div", { class: "text-5xl mb-4", children: "\u{1F393}" }), s("h3", { class: "text-xl font-bold mb-3", children: "Education First" }), s("p", { class: "text-gray-400", children: "Comprehensive education over quick profits. Understanding WHY markets move." })] }), s("div", { class: "card text-center", children: [s("div", { class: "text-5xl mb-4", children: "\u{1F48E}" }), s("h3", { class: "text-xl font-bold mb-3", children: "Transparency" }), s("p", { class: "text-gray-400", children: "Real trades, real results, real mistakes. No fake screenshots or promises." })] }), s("div", { class: "card text-center", children: [s("div", { class: "text-5xl mb-4", children: "\u{1F91D}" }), s("h3", { class: "text-xl font-bold mb-3", children: "Community" }), s("p", { class: "text-gray-400", children: "Supportive community where members learn together and grow together." })] })] }), s("div", { class: "text-center", children: s("a", { href: "/waitlist", class: "btn btn-primary", children: "Join Our Community" }) })] }) }) })] })));
O.get("/faq", (e) => e.render(s(q, { children: [s("section", { class: "hero py-16", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Frequently Asked ", s("span", { class: "gradient-text", children: "Questions" })] }), s("p", { class: "text-xl text-gray-300 max-w-3xl mx-auto", children: "Everything you need to know about Futures Trading Academy" })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "space-y-6", children: [s("div", { class: "card", children: [s("h3", { class: "text-xl font-bold mb-3", children: "What is Futures Trading Academy?" }), s("p", { class: "text-gray-400", children: "A comprehensive online education platform teaching institutional-grade trading strategies for futures markets, focusing on auction market theory, smart money concepts, and CME fair price redelivery." })] }), s("div", { class: "card", children: [s("h3", { class: "text-xl font-bold mb-3", children: "Do I need prior trading experience?" }), s("p", { class: "text-gray-400", children: "No prior experience required. Our Foundation Tier starts with basics and builds progressively." })] }), s("div", { class: "card", children: [s("h3", { class: "text-xl font-bold mb-3", children: "How long does it take to complete?" }), s("p", { class: "text-gray-400", children: "The complete curriculum contains 40+ hours of video content. Most students complete the full program in 3-6 months when studying part-time." })] }), s("div", { class: "card", children: [s("h3", { class: "text-xl font-bold mb-3", children: "Is there a money-back guarantee?" }), s("p", { class: "text-gray-400", children: "Yes, we offer a 14-day money-back guarantee for first-time subscribers. If you're not satisfied with the content quality, we'll provide a full refund." })] })] }), s("div", { class: "text-center mt-12", children: s("a", { href: "/waitlist", class: "btn btn-primary", children: "Join Waitlist" }) })] }) })] })));
O.get("/contact", (e) => e.render(s(q, { children: s("section", { class: "py-20 bg-slate-900 min-h-screen flex items-center justify-center", children: s("div", { class: "max-w-4xl mx-auto px-4 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Contact ", s("span", { class: "gradient-text", children: "Us" })] }), s("p", { class: "text-xl text-gray-400 mb-8", children: "Have questions? Join our waitlist and we'll reach out to you personally." }), s("a", { href: "/waitlist", class: "btn btn-primary", children: "Join Waitlist" })] }) }) })));
O.get("/downloads", (e) => e.render(s(q, { children: [s("section", { class: "hero py-16", children: s("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Documentation ", s("span", { class: "gradient-text", children: "Downloads" })] }), s("p", { class: "text-xl text-gray-300 max-w-3xl mx-auto", children: "Download comprehensive guides for setup, deployment, and launch strategy" })] }) }), s("section", { class: "py-20 bg-slate-900", children: s("div", { class: "max-w-5xl mx-auto px-4 sm:px-6 lg:px-8", children: [s("div", { class: "grid md:grid-cols-3 gap-8", children: [s("div", { class: "card text-center", children: [s("div", { class: "text-6xl mb-4", children: "\u{1F4D8}" }), s("h3", { class: "text-2xl font-bold mb-3", children: "README" }), s("p", { class: "text-gray-400 mb-4 text-sm", children: "Complete technical documentation including setup, features, architecture, and deployment instructions." }), s("div", { class: "text-gray-500 text-sm mb-4", children: [s("i", { class: "fas fa-file-alt mr-2" }), " 8.8 KB"] }), s("a", { href: "https://github.com/YOUR-USERNAME/futures-trading-academy/blob/main/README.md", target: "_blank", class: "btn btn-primary w-full", children: [s("i", { class: "fas fa-external-link-alt mr-2" }), "View README"] }), s("p", { class: "text-gray-500 text-xs mt-2", children: "Available in project root directory" })] }), s("div", { class: "card text-center", children: [s("div", { class: "text-6xl mb-4", children: "\u{1F680}" }), s("h3", { class: "text-2xl font-bold mb-3", children: "Deployment Guide" }), s("p", { class: "text-gray-400 mb-4 text-sm", children: "Step-by-step integration guide for external services, setup checklists, and launch day procedures." }), s("div", { class: "text-gray-500 text-sm mb-4", children: [s("i", { class: "fas fa-file-alt mr-2" }), " 11.4 KB"] }), s("a", { href: "https://github.com/YOUR-USERNAME/futures-trading-academy/blob/main/DEPLOYMENT_GUIDE.md", target: "_blank", class: "btn btn-gold w-full", children: [s("i", { class: "fas fa-external-link-alt mr-2" }), "View Guide"] }), s("p", { class: "text-gray-500 text-xs mt-2", children: "Available in project root directory" })] }), s("div", { class: "card text-center", children: [s("div", { class: "text-6xl mb-4", children: "\u{1F4CA}" }), s("h3", { class: "text-2xl font-bold mb-3", children: "Project Summary" }), s("p", { class: "text-gray-400 mb-4 text-sm", children: "Executive overview with launch strategy, success metrics, cost breakdown, and quick wins checklist." }), s("div", { class: "text-gray-500 text-sm mb-4", children: [s("i", { class: "fas fa-file-alt mr-2" }), " 10.4 KB"] }), s("a", { href: "https://github.com/YOUR-USERNAME/futures-trading-academy/blob/main/PROJECT_SUMMARY.md", target: "_blank", class: "btn btn-secondary w-full", children: [s("i", { class: "fas fa-external-link-alt mr-2" }), "View Summary"] }), s("p", { class: "text-gray-500 text-xs mt-2", children: "Available in project root directory" })] })] }), s("div", { class: "text-center mt-12", children: s("div", { class: "card bg-blue-900/20 border-blue-500/30", children: [s("div", { class: "mb-4", children: s("i", { class: "fas fa-info-circle text-4xl text-blue-400" }) }), s("h3", { class: "text-xl font-bold mb-3", children: "How to Access Documentation" }), s("p", { class: "text-gray-300 mb-4", children: "All documentation files are included in the project root directory when you clone or deploy this project." }), s("div", { class: "grid md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto", children: [s("div", { class: "bg-slate-800 p-4 rounded-lg", children: [s("h4", { class: "font-bold mb-2 text-blue-400", children: [s("i", { class: "fas fa-folder mr-2" }), "Local Access"] }), s("p", { class: "text-sm text-gray-400", children: "Files are in your project root:" }), s("code", { class: "text-xs bg-slate-900 p-2 block mt-2 rounded", children: ["webapp/README.md", s("br", {}), "webapp/DEPLOYMENT_GUIDE.md", s("br", {}), "webapp/PROJECT_SUMMARY.md"] })] }), s("div", { class: "bg-slate-800 p-4 rounded-lg", children: [s("h4", { class: "font-bold mb-2 text-green-400", children: [s("i", { class: "fab fa-github mr-2" }), "GitHub Access"] }), s("p", { class: "text-sm text-gray-400", children: "View online after pushing to GitHub:" }), s("a", { href: "https://github.com", target: "_blank", class: "text-xs text-blue-400 hover:underline block mt-2", children: "github.com/your-repo \u2192" })] })] }), s("p", { class: "text-gray-500 text-sm mt-4", children: "All files are in Markdown format (.md) - open with any text editor, VS Code, or online Markdown viewer" })] }) }), s("div", { class: "card mt-12", children: [s("h3", { class: "text-2xl font-bold mb-6 text-center", children: "What's Included" }), s("div", { class: "grid md:grid-cols-3 gap-6", children: [s("div", { children: [s("h4", { class: "font-bold mb-2 text-blue-400", children: "README.md" }), s("ul", { class: "text-sm text-gray-400 space-y-1", children: [s("li", { children: "\u2022 Project overview" }), s("li", { children: "\u2022 Tech stack details" }), s("li", { children: "\u2022 Setup instructions" }), s("li", { children: "\u2022 Available scripts" }), s("li", { children: "\u2022 Architecture info" }), s("li", { children: "\u2022 Performance notes" })] })] }), s("div", { children: [s("h4", { class: "font-bold mb-2 text-yellow-400", children: "DEPLOYMENT_GUIDE.md" }), s("ul", { class: "text-sm text-gray-400 space-y-1", children: [s("li", { children: "\u2022 Service integration" }), s("li", { children: "\u2022 Setup checklists" }), s("li", { children: "\u2022 API configurations" }), s("li", { children: "\u2022 Launch day plan" }), s("li", { children: "\u2022 Marketing strategy" }), s("li", { children: "\u2022 Troubleshooting" })] })] }), s("div", { children: [s("h4", { class: "font-bold mb-2 text-green-400", children: "PROJECT_SUMMARY.md" }), s("ul", { class: "text-sm text-gray-400 space-y-1", children: [s("li", { children: "\u2022 Executive overview" }), s("li", { children: "\u2022 Cost breakdown" }), s("li", { children: "\u2022 Success metrics" }), s("li", { children: "\u2022 Quick wins list" }), s("li", { children: "\u2022 Iteration plan" }), s("li", { children: "\u2022 Launch strategy" })] })] })] })] }), s("div", { class: "card mt-8 bg-blue-900/20 border-blue-500/30", children: s("div", { class: "flex items-start", children: [s("div", { class: "text-3xl mr-4", children: "\u{1F4A1}" }), s("div", { children: [s("h4", { class: "font-bold mb-2", children: "Need Help?" }), s("p", { class: "text-gray-400 text-sm", children: ["Start with the ", s("strong", { children: "README.md" }), " for technical setup, then follow the", s("strong", { children: "DEPLOYMENT_GUIDE.md" }), " for integration. Use ", s("strong", { children: "PROJECT_SUMMARY.md" }), "for business strategy and launch planning."] })] })] }) })] }) })] })));
O.get("/terms", (e) => e.render(s(q, { children: s("section", { class: "py-20 bg-slate-900 min-h-screen flex items-center justify-center", children: s("div", { class: "max-w-4xl mx-auto px-4 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Terms of ", s("span", { class: "gradient-text", children: "Service" })] }), s("p", { class: "text-gray-400", children: "Coming soon" })] }) }) })));
O.get("/privacy", (e) => e.render(s(q, { children: s("section", { class: "py-20 bg-slate-900 min-h-screen flex items-center justify-center", children: s("div", { class: "max-w-4xl mx-auto px-4 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Privacy ", s("span", { class: "gradient-text", children: "Policy" })] }), s("p", { class: "text-gray-400", children: "Coming soon" })] }) }) })));
O.get("/disclaimer", (e) => e.render(s(q, { children: s("section", { class: "py-20 bg-slate-900 min-h-screen flex items-center justify-center", children: s("div", { class: "max-w-4xl mx-auto px-4 text-center", children: [s("h1", { class: "text-5xl font-bold mb-6", children: ["Risk ", s("span", { class: "gradient-text", children: "Disclaimer" })] }), s("p", { class: "text-gray-400", children: "Trading futures involves substantial risk of loss. Past performance is not indicative of future results." })] }) }) })));
var zt = new Pr();
var vi = Object.assign({ "/src/index.tsx": O });
var Fr = false;
for (const [, e] of Object.entries(vi)) e && (zt.all("*", (t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), zt.notFound((t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), Fr = true);
if (!Fr) throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");
var drainBody = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
__name2(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } catch (e) {
    const error32 = reduceError(e);
    return Response.json(error32, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = zt;
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
__name2(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env22, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env22, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
__name2(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env22, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env22, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");
__name2(__facade_invoke__, "__facade_invoke__");
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  static {
    __name(this, "___Facade_ScheduledController__");
  }
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name2(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name2(function(request, env22, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env22, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env22, ctx) {
      const dispatcher = /* @__PURE__ */ __name2(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env22, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env22, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
__name2(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name2((request, env22, ctx) => {
      this.env = env22;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name2((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
__name2(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;

// node_modules/wrangler/templates/pages-dev-util.ts
function isRoutingRuleMatch(pathname, routingRule) {
  if (!pathname) {
    throw new Error("Pathname is undefined.");
  }
  if (!routingRule) {
    throw new Error("Routing rule is undefined.");
  }
  const ruleRegExp = transformRoutingRuleToRegExp(routingRule);
  return pathname.match(ruleRegExp) !== null;
}
__name(isRoutingRuleMatch, "isRoutingRuleMatch");
function transformRoutingRuleToRegExp(rule) {
  let transformedRule;
  if (rule === "/" || rule === "/*") {
    transformedRule = rule;
  } else if (rule.endsWith("/*")) {
    transformedRule = `${rule.substring(0, rule.length - 2)}(/*)?`;
  } else if (rule.endsWith("/")) {
    transformedRule = `${rule.substring(0, rule.length - 1)}(/)?`;
  } else if (rule.endsWith("*")) {
    transformedRule = rule;
  } else {
    transformedRule = `${rule}(/)?`;
  }
  transformedRule = `^${transformedRule.replaceAll(/\./g, "\\.").replaceAll(/\*/g, ".*")}$`;
  return new RegExp(transformedRule);
}
__name(transformRoutingRuleToRegExp, "transformRoutingRuleToRegExp");

// .wrangler/tmp/pages-G43smt/mxcflds50no.js
var define_ROUTES_default = { version: 1, include: ["/*"], exclude: ["/static/*"] };
var routes = define_ROUTES_default;
var pages_dev_pipeline_default = {
  fetch(request, env3, context3) {
    const { pathname } = new URL(request.url);
    for (const exclude of routes.exclude) {
      if (isRoutingRuleMatch(pathname, exclude)) {
        return env3.ASSETS.fetch(request);
      }
    }
    for (const include of routes.include) {
      if (isRoutingRuleMatch(pathname, include)) {
        const workerAsHandler = middleware_loader_entry_default;
        if (workerAsHandler.fetch === void 0) {
          throw new TypeError("Entry point missing `fetch` handler");
        }
        return workerAsHandler.fetch(request, env3, context3);
      }
    }
    return env3.ASSETS.fetch(request);
  }
};

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default2 = drainBody2;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError2(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError2(e.cause)
  };
}
__name(reduceError2, "reduceError");
var jsonError2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } catch (e) {
    const error4 = reduceError2(e);
    return Response.json(error4, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default2 = jsonError2;

// .wrangler/tmp/bundle-F8TZm2/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__2 = [
  middleware_ensure_req_body_drained_default2,
  middleware_miniflare3_json_error_default2
];
var middleware_insertion_facade_default2 = pages_dev_pipeline_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__2 = [];
function __facade_register__2(...args) {
  __facade_middleware__2.push(...args.flat());
}
__name(__facade_register__2, "__facade_register__");
function __facade_invokeChain__2(request, env3, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__2(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env3, ctx, middlewareCtx);
}
__name(__facade_invokeChain__2, "__facade_invokeChain__");
function __facade_invoke__2(request, env3, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__2(request, env3, ctx, dispatch, [
    ...__facade_middleware__2,
    finalMiddleware
  ]);
}
__name(__facade_invoke__2, "__facade_invoke__");

// .wrangler/tmp/bundle-F8TZm2/middleware-loader.entry.ts
var __Facade_ScheduledController__2 = class ___Facade_ScheduledController__2 {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__2)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler2(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env3, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env3, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env3, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__2(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env3, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__2(request, env3, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler2, "wrapExportedHandler");
function wrapWorkerEntrypoint2(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env3, ctx) => {
      this.env = env3;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__2(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__2(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint2, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY2;
if (typeof middleware_insertion_facade_default2 === "object") {
  WRAPPED_ENTRY2 = wrapExportedHandler2(middleware_insertion_facade_default2);
} else if (typeof middleware_insertion_facade_default2 === "function") {
  WRAPPED_ENTRY2 = wrapWorkerEntrypoint2(middleware_insertion_facade_default2);
}
var middleware_loader_entry_default2 = WRAPPED_ENTRY2;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__2 as __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default2 as default
};
//# sourceMappingURL=mxcflds50no.js.map
